<?php
// =========================================
// Página de perfil de usuario
// Permite ver y editar información personal, valoraciones y reportar usuarios
// =========================================

session_start();
if (!isset($_SESSION['usuario'])) {
    header('Location: index.php');
    exit();
}
include 'php/db_config.php';
$usuario = $_GET['usuario'] ?? $_SESSION['usuario'];
// Si el usuario logueado cambió su nombre, fuerza mostrar su propio perfil
if (!isset($_GET['usuario']) || $_GET['usuario'] === $_SESSION['usuario']) {
    $usuario = $_SESSION['usuario'];
}
// Datos básicos
$stmt = $conn->prepare('SELECT usuario FROM usuarios WHERE usuario=?');
$stmt->bind_param('s', $usuario);
$stmt->execute();
$stmt->store_result();
if ($stmt->num_rows === 0) {
    // Si el usuario logueado, muestra su propio perfil
    if ($usuario === $_SESSION['usuario']) {
        $nombreUsuario = $_SESSION['usuario'];
    } else {
        echo '<h3>Usuario no encontrado</h3>';
        exit();
    }
} else {
    $stmt->bind_result($nombreUsuario);
    $stmt->fetch();
}
$stmt->close();
// Valoraciones recibidas
$valoraciones = [];
$stmt = $conn->prepare('SELECT evaluador, puntuacion, comentario, fecha FROM valoraciones WHERE evaluado=? ORDER BY fecha DESC');
$stmt->bind_param('s', $usuario);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $valoraciones[] = $row;
}
$stmt->close();
$conn->close();
?>
<!-- Vista principal del perfil de usuario -->
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Perfil de <?php echo htmlspecialchars($nombreUsuario); ?></title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="css/dashboard.css" rel="stylesheet">
  <style>
    body {
      background: linear-gradient(135deg, #e0eafc 0%, #cfdef3 100%);
      min-height: 100vh;
      background-size: 200% 200%;
      animation: bgMove 16s linear infinite alternate;
    }
    @keyframes bgMove {
      0% {background-position: 0% 50%;}
      100% {background-position: 100% 50%;}
    }
    .profile-header {
      background: linear-gradient(90deg, #43cea2 0%, #185a9d 100%);
      color: #fff;
      border-radius: 1.5rem;
      box-shadow: 0 4px 24px rgba(0,0,0,0.08);
      padding: 2rem 2rem 1rem 2rem;
      margin-bottom: 2rem;
      position: relative;
      overflow: hidden;
      text-align: center;
    }
    .profile-avatar {
      width: 110px;
      height: 110px;
      border-radius: 50%;
      border: 4px solid #fff;
      object-fit: cover;
      margin-top: -70px;
      box-shadow: 0 2px 12px rgba(0,0,0,0.2);
      background: radial-gradient(circle at 60% 40%, #43cea2 60%, #185a9d 100%);
      display: flex; align-items: center; justify-content: center;
      font-size: 2.5rem; font-weight: 700; color: #fff;
    }
    .valoracion-card {
      transition: box-shadow 0.3s, filter 0.3s;
      border: none;
      background: #f8fafc;
      border-radius: 1rem;
      box-shadow: 0 2px 8px rgba(67,206,162,0.07);
      filter: brightness(1) drop-shadow(0 0 0px #43cea2);
    }
    .valoracion-card:hover {
      box-shadow: 0 8px 32px rgba(67,206,162,0.18);
      filter: brightness(1.05) drop-shadow(0 0 6px #43cea2);
    }
    .star {
      color: #ffb300;
      font-size: 1.2em;
      filter: drop-shadow(0 0 2px #ffb300);
    }
    .profile-stats {
      display: flex;
      justify-content: center;
      gap: 2rem;
      margin: 1.5rem 0 0.5rem 0;
    }
    .profile-stat {
      background: #fff;
      border-radius: 1rem;
      padding: 1rem 2rem;
      box-shadow: 0 2px 8px rgba(67,206,162,0.07);
      text-align: center;
    }
    .profile-stat .stat-value {
      font-size: 1.3rem;
      font-weight: bold;
      color: #185a9d;
    }
    .profile-stat .stat-label {
      font-size: 0.9rem;
      color: #888;
    }
    .animated-link {
      color: #185a9d;
      text-decoration: underline;
      transition: color 0.2s;
    }
    .animated-link:hover {
      color: #43cea2;
      letter-spacing: 1px;
    }
  </style>
</head>
<body>
<!-- Contenedor principal del perfil -->
<div class="container mt-5">
      <!-- Encabezado del perfil con nombre y avatar -->
    <div class="profile-header mx-auto mb-4">
    <div style="position: relative; display: flex; flex-direction: column; align-items: center;">
      <div style="margin-top: -60px;">
        <div class="profile-avatar d-flex align-items-center justify-content-center shadow" style="background: radial-gradient(circle at 60% 40%, #4ac367 60%, #34a85a 100%);">
          <?php echo strtoupper(substr($nombreUsuario,0,1)); ?>
        </div>
      </div>
      <h2 class="mt-2 mb-0 fw-bold"> <?php echo htmlspecialchars($nombreUsuario); ?> </h2>
      <a href="dashboard.php" class="animated-link mt-2">← Volver al dashboard</a>
      <!-- Sección editar nombre usuario solo si es su propio perfil -->
      <?php if ($_SESSION['usuario'] === $usuario): ?>
      <div class="mt-3 mb-2">
        <?php
        include 'php/db_config.php';
        $stmt = $conn->prepare('SELECT ultimo_cambio_nombre FROM usuarios WHERE usuario=?');
        $stmt->bind_param('s', $_SESSION['usuario']);
        $stmt->execute();
        $stmt->bind_result($ultimo_cambio_nombre);
        $stmt->fetch();
        $stmt->close();
        $conn->close();
        $dias_restantes = 0;
        if ($ultimo_cambio_nombre) {
          $ultimo = new DateTime($ultimo_cambio_nombre);
          $ahora = new DateTime();
          $dias = $ahora->diff($ultimo)->days;
          if ($dias < 30) {
            $dias_restantes = 30 - $dias;
          }
        }
        ?>
        <form id="formEditarUsuario" class="row g-2 align-items-center justify-content-center">
          <div class="col-auto">
            <input type="text" class="form-control input-cambio-nombre" id="nuevoUsuario" name="nuevoUsuario" placeholder="Nuevo nombre de usuario" minlength="3" maxlength="32" required <?php if($dias_restantes>0) echo 'disabled'; ?> style="background:#fff; color:#222; border:2px solid #43cea2; font-weight:500; letter-spacing:0.5px;" autocomplete="off">
          </div>
          <div class="col-auto">
            <button type="submit" class="btn btn-outline-primary btn-cambio-nombre" <?php if($dias_restantes>0) echo 'disabled'; ?> style="color:#222; background:#fff; border:2px solid #43cea2; font-weight:600;">Cambiar nombre</button>
          </div>
        </form>
        <div class="small mt-1 text-muted">
          <?php if($dias_restantes>0): ?>
            Podrás cambiar tu nombre en <b><?php echo $dias_restantes; ?></b> día(s).
          <?php else: ?>
            Puedes cambiar tu nombre ahora. Solo se permite 1 cambio cada 30 días.
          <?php endif; ?>
        </div>
        <div id="msgEditarUsuario" class="mt-2"></div>
      </div>
      <?php endif; ?>
      </div>
      <script>
      document.addEventListener('DOMContentLoaded', function(){
        var form = document.getElementById('formEditarUsuario');
        if(form){
          form.onsubmit = function(e){
            e.preventDefault();
            var input = document.getElementById('nuevoUsuario');
            var msg = document.getElementById('msgEditarUsuario');
            msg.innerHTML = '';
            fetch('php/editar_nombre_usuario.php', {
              method: 'POST',
              body: new URLSearchParams({nuevo_usuario: input.value})
            })
            .then(r=>r.json())
            .then(resp=>{
              if(resp.success){
                msg.innerHTML = '<div class="alert alert-success">Nombre actualizado: <b>'+resp.nuevo_usuario+'</b></div>';
                setTimeout(()=>window.location.reload(), 1200);
              }else{
                msg.innerHTML = '<div class="alert alert-danger">'+resp.error+'</div>';
              }
            })
            .catch(()=>{
              msg.innerHTML = '<div class="alert alert-danger">Error de red.</div>';
            });
          }
        }
      });
      </script>
      <div class="profile-stats mt-3">
        <div class="profile-stat">
          <div class="stat-value"><?php echo count($valoraciones); ?></div>
          <div class="stat-label">Valoraciones</div>
        </div>
        <!-- Aquí puedes agregar más estadísticas -->
      </div>
    </div>
  </div>
    <!-- Sección de valoraciones recibidas -->
  <div class="mb-4">
    <h5 class="mb-3">Valoraciones recibidas:</h5>
    <?php if (count($valoraciones) === 0): ?>
      <p class="text-muted">Sin valoraciones aún.</p>
    <?php else: ?>
      <div class="row g-3">
      <?php foreach ($valoraciones as $v): ?>
        <div class="col-12 col-md-6 col-lg-4">
          <div class="card valoracion-card h-100 p-3">
            <div class="d-flex align-items-center mb-2">
              <div class="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center me-2" style="width:36px;height:36px;font-size:1.2rem;font-weight:600;">
                <?php echo strtoupper(substr($v['evaluador'],0,1)); ?>
              </div>
              <div>
                <b><?php echo htmlspecialchars($v['evaluador']); ?></b>
                <span class="ms-1">
                  <?php for($i=1;$i<=5;$i++): ?>
                    <span class="star<?php if($i>$v['puntuacion']) echo ' text-muted'; ?>">&#9733;</span>
                  <?php endfor; ?>
                </span>
                <span class="badge bg-success ms-2"><?php echo $v['puntuacion']; ?>/5</span>
              </div>
            </div>
            <div class="mb-2 text-secondary fst-italic">"<?php echo htmlspecialchars($v['comentario']); ?>"</div>
            <div class="text-muted small text-end"><?php echo date('d/m/Y', strtotime($v['fecha'])); ?></div>
          </div>
        </div>
      <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </div>
    <!-- Sección de acciones: contactar soporte y reportar usuario -->
  <div class="text-center mt-4">
    <h5 class="mb-3">¿Tienes algún problema?</h5>
    <button class="btn btn-outline-primary btn-lg px-4 shadow-sm" data-bs-toggle="modal" data-bs-target="#modalSoporte">
      <i class="bi bi-life-preserver me-2"></i>Contactar con soporte
    </button>
    <br><br>
    <button class="btn btn-outline-danger btn-lg px-4 shadow-sm" data-bs-toggle="modal" data-bs-target="#modalReporte">
      <i class="bi bi-flag me-2"></i>Reportar usuario
    </button>
  </div>
</div>
<!-- Modal para contactar con soporte -->

<!-- Modal para reportar a un usuario -->
<div class="modal fade" id="modalReporte" tabindex="-1" aria-labelledby="modalReporteLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <form method="POST" action="php/reportar_usuario.php">
        <div class="modal-header">
          <h5 class="modal-title" id="modalReporteLabel">Reportar usuario: <?php echo htmlspecialchars($nombreUsuario); ?></h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
        </div>
        <div class="modal-body">
          <input type="hidden" name="usuario_reportado" value="<?php echo htmlspecialchars($nombreUsuario); ?>">
          <div class="mb-3">
            <label class="form-label">Motivo</label>
            <select class="form-select" name="motivo" required>
              <option value="">Selecciona un motivo</option>
              <option value="Lenguaje inapropiado">Lenguaje inapropiado</option>
              <option value="Incumplimiento de acuerdo">Incumplimiento de acuerdo</option>
              <option value="Comportamiento sospechoso">Comportamiento sospechoso</option>
              <option value="Otro">Otro</option>
            </select>
          </div>
          <div class="mb-3">
            <label class="form-label">Mensaje (opcional)</label>
            <textarea class="form-control" name="mensaje" rows="3" placeholder="Describe la situación..."></textarea>
          </div>
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-danger">Enviar reporte</button>
        </div>
      </form>
    </div>
  </div>
</div>

<div class="modal fade" id="modalSoporte" tabindex="-1" aria-labelledby="modalSoporteLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <form method="POST" action="php/enviar_soporte.php">
        <div class="modal-header">
          <h5 class="modal-title" id="modalSoporteLabel">Contactar con soporte</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
        </div>
        <div class="modal-body">
          <div class="mb-3">
            <label class="form-label">Correo electrónico de contacto</label>
            <input type="email" class="form-control" name="email" placeholder="tu@email.com" required>
          </div>
          <div class="mb-3">
            <label class="form-label">¿En qué podemos ayudarte?</label>
            <textarea class="form-control" name="mensaje" rows="4" required></textarea>
          </div>
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-primary">Enviar mensaje</button>
        </div>
      </form>
    </div>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
