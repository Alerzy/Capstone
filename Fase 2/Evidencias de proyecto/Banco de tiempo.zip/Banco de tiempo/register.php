<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Registro - Banco de Tiempo</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="css/register.css" rel="stylesheet">
</head>
<body>
    <!-- Contenedor principal del formulario de registro -->
  <div class="container mt-5 fade-in">
    <div class="row justify-content-center">
            <!-- Columna central para el formulario -->
      <div class="col-md-5">
                <!-- Tarjeta con padding para el formulario -->
        <div class="card p-4">
                    <!-- Título del formulario -->
          <h3 class="text-center mb-4">Registro</h3>
                    <!-- Mensaje de error si el usuario ya existe -->
          <?php if (isset($_GET['error']) && $_GET['error'] === 'usuario'): ?>
            <div class="alert alert-danger">El nombre de usuario ya está en uso. Por favor elige otro.</div>
          <?php endif; ?>
                    <!-- Formulario de registro de usuario -->
          <form action="php/register.php" method="POST">
                        <!-- Campo para el nombre de usuario -->
            <div class="mb-3">
              <label class="form-label">Usuario:</label>
              <input type="text" name="usuario" class="form-control" required>
            </div>
                        <!-- Campo para la contraseña -->
            <div class="mb-3">
              <label class="form-label">Contraseña:</label>
              <input type="password" name="contrasena" class="form-control" required>
            </div>
                        <!-- Botón para enviar el formulario de registro -->
            <button type="submit" class="btn btn-custom w-100">Registrar</button>
                        <!-- Enlace para volver a la página de inicio -->
            <a href="index.php" class="btn btn-custom w-100 mt-2">Volver al inicio</a>
          </form>
        </div>
      </div>
    </div>
  </div>
  <!-- Fin del body principal -->
</body>
</html>
