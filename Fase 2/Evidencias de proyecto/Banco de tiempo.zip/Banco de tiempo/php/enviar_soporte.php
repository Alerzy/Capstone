<?php
// Script sencillo para recibir mensajes de soporte
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = trim($_POST['email'] ?? '');
    $mensaje = trim($_POST['mensaje'] ?? '');

    // Aquí puedes guardar el mensaje en la base de datos, enviarlo por correo, o simplemente mostrar una alerta de recibido
    // Por simplicidad, solo mostramos un mensaje de éxito
    echo '<script>alert("¡Tu mensaje fue enviado al soporte! Pronto recibirás respuesta en tu correo."); window.location.href = "../dashboard.php";</script>';
    exit();
}

// Si se accede directamente a este script sin enviar un formulario, redirige a la página de dashboard
header('Location: ../dashboard.php');
exit();
