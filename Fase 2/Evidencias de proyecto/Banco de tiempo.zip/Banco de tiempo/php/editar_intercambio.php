<?php
session_start();
header('Content-Type: application/json');
if (!isset($_SESSION['usuario'])) {
    echo json_encode(['success' => false, 'error' => 'No autenticado']);
    exit;
}
include 'db_config.php';
$usuario = $conn->real_escape_string($_SESSION['usuario']);

// Recoger datos del POST
$id = isset($_POST['id']) ? intval($_POST['id']) : 0;
$servicio_ofrecido = $conn->real_escape_string($_POST['servicio_ofrecido'] ?? '');
$horas_ofrecidas = intval($_POST['horas_ofrecidas'] ?? 0);
$servicio_deseado = $conn->real_escape_string($_POST['servicio_deseado'] ?? '');
$horas_deseadas = intval($_POST['horas_deseadas'] ?? 0);
$descripcion = $conn->real_escape_string($_POST['descripcion'] ?? '');

if ($id <= 0 || !$servicio_ofrecido || !$horas_ofrecidas || !$servicio_deseado || !$horas_deseadas || !$descripcion) {
    echo json_encode(['success' => false, 'error' => 'Datos incompletos']);
    exit;
}

// Solo permitir editar publicaciones propias y que NO estén finalizadas
$resEstado = $conn->query("SELECT estado FROM intercambios WHERE id=$id AND usuario='$usuario'");
if ($row = $resEstado->fetch_assoc()) {
    if ($row['estado'] === 'finalizado') {
        echo json_encode(['success' => false, 'error' => 'No se puede editar un intercambio finalizado.']);
        $conn->close();
        exit;
    }
} else {
    echo json_encode(['success' => false, 'error' => 'No autorizado o intercambio no encontrado.']);
    $conn->close();
    exit;
}

$sql = "UPDATE intercambios SET servicio_ofrecido='$servicio_ofrecido', horas_ofrecidas=$horas_ofrecidas, servicio_deseado='$servicio_deseado', horas_deseadas=$horas_deseadas, descripcion='$descripcion' WHERE id=$id AND usuario='$usuario'";

if ($conn->query($sql) === TRUE) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'error' => $conn->error]);
}
$conn->close();
