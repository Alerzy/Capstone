<?php
// =========================================
// Script para consultar intercambios del usuario
// Valida sesión, consulta y retorna intercambios
// =========================================

// Inicia la sesión para validar al usuario
// Inicia la sesión para validar al usuario
session_start();

// Incluye la configuración de la base de datos
// Incluye la configuración de la base de datos
include("db_config.php");

// Establece el tipo de contenido de la respuesta en JSON
// Establece el tipo de contenido de la respuesta en JSON
header('Content-Type: application/json');

// Consulta a la base de datos para obtener los intercambios disponibles
// Selecciona todos los campos de la tabla intercambios donde el estado no sea 'finalizado'
// Ordena los resultados por fecha de creación en orden descendente
// Consulta SQL: selecciona intercambios no finalizados ordenados por fecha de creación descendente
$sql = "SELECT * FROM intercambios WHERE estado != 'finalizado' ORDER BY fecha_creacion DESC";

// Ejecuta la consulta y almacena el resultado en la variable $resultado
// Ejecuta la consulta y almacena el resultado
$resultado = $conn->query($sql);
?>

<!-- Vista HTML de los intercambios disponibles -->
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Intercambios Disponibles</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
        <!--
      Estilos CSS para la página de intercambios disponibles
      Incluye fondo animado, tarjetas modernas y badges personalizados
    -->
    <style>
            /* Fondo animado con gradiente azul y movimiento */
      body {
        background: linear-gradient(135deg, #e0eafc 0%, #cfdef3 100%);
        min-height: 100vh;
        background-size: 200% 200%;
        animation: bgMove 16s linear infinite alternate;
      }
            /* Animación de movimiento para el fondo */
      @keyframes bgMove {
        0% {background-position: 0% 50%;}
        100% {background-position: 100% 50%;}
      }
            /* Tarjeta moderna para cada intercambio */
      .modern-card {
        background: #fff;
        border-radius: 1.3rem;
        box-shadow: 0 4px 24px rgba(67,206,162,0.10);
        margin-bottom: 2rem;
        padding: 2rem 2rem 1.2rem 2rem;
        border-left: 7px solid #43cea2;
        transition: box-shadow 0.2s, border-color 0.2s;
      }
            /* Efecto hover para resaltar la tarjeta */
      .modern-card:hover {
        box-shadow: 0 8px 32px rgba(67,206,162,0.18);
        border-left: 7px solid #185a9d;
      }
            /* Badge para mostrar el servicio ofrecido o deseado */
      .badge-servicio {
        background: linear-gradient(90deg, #43cea2 0%, #185a9d 100%);
        color: #fff;
        font-size: 1em;
        padding: 0.4em 1em;
        border-radius: 1em;
        margin-right: 0.5em;
      }
            /* Badge para mostrar la cantidad de horas */
      .badge-horas {
        background: #f8fafc;
        color: #185a9d;
        font-weight: 600;
        font-size: 1em;
        padding: 0.3em 0.9em;
        border-radius: 1em;
        margin-right: 0.5em;
        border: 1.5px solid #43cea2;
      }
            /* Estilo para el nombre del usuario */
      .usuario-nombre {
        font-weight: 700;
        color: #185a9d;
        font-size: 1.2em;
        letter-spacing: 0.5px;
      }
            /* Contenedor de acciones (botones) en la tarjeta */
      .modern-actions {
        display: flex;
        gap: 0.7em;
        margin-top: 1.2em;
      }
            /* Botón animado con sombra y transición */
      .btn-anim {
        transition: transform 0.18s cubic-bezier(.4,2,.6,1), box-shadow 0.18s, background 0.2s, color 0.2s;
        box-shadow: 0 2px 8px rgba(67,206,162,0.07);
        font-weight: 600;
        letter-spacing: 0.5px;
        border-width: 2px;
        border-radius: 2em;
        font-size: 1em;
        padding: 0.5em 1.2em;
        display: flex;
        align-items: center;
        gap: 0.4em;
      }
            /* Efecto hover/focus para el botón animado */
      .btn-anim:hover, .btn-anim:focus {
        transform: scale(1.08) translateY(-2px);
        box-shadow: 0 6px 24px rgba(67,206,162,0.13);
        filter: brightness(1.08);
        z-index: 2;
      }
            /* Botón para ver el perfil del usuario */
      .btn-ver-perfil {
        background: linear-gradient(90deg, #43cea2 0%, #185a9d 100%);
        color: #fff !important;
        border-color: #43cea2;
      }
            /* Efecto hover/focus para el botón de ver perfil */
      .btn-ver-perfil:hover, .btn-ver-perfil:focus {
        background: linear-gradient(90deg, #185a9d 0%, #43cea2 100%);
        color: #fff !important;
        border-color: #185a9d;
      }
            /* Botón para reportar usuario */
      .btn-reportar {
        background: linear-gradient(90deg, #ff5f6d 0%, #ffc371 100%);
        color: #fff !important;
        border-color: #ff5f6d;
      }
            /* Efecto hover/focus para el botón de reportar */
      .btn-reportar:hover, .btn-reportar:focus {
        background: linear-gradient(90deg, #ffc371 0%, #ff5f6d 100%);
        color: #fff !important;
        border-color: #ffc371;
      }
            /* Botón de aceptar intercambio */
      .btn-success {
        border-radius: 2em;
        font-weight: 600;
        letter-spacing: 0.5px;
        padding: 0.5em 1.2em;
      }
            /* Etiqueta secundaria en la tarjeta */
      .modern-label {
        color: #888;
        font-size: 0.96em;
        margin-right: 0.3em;
        font-weight: 500;
      }
            /* Descripción del intercambio */
      .modern-card .descripcion {
        color: #444;
        font-size: 1.05em;
        margin-top: 0.5em;
        margin-bottom: 0.5em;
      }
            /* Fecha de creación del intercambio */
      .modern-card .fecha {
        font-size: 0.95em;
        color: #999;
        text-align: end;
      }
    </style>
</head>
<body class="bg-light">

<!-- Contenedor principal de la lista de intercambios -->
<div class="container mt-5">
        <!-- Título de la sección -->
    <h2 class="text-center mb-4">Intercambios Disponibles</h2>

        <?php // Si hay resultados, recorre cada intercambio y lo muestra en una tarjeta
    if ($resultado->num_rows > 0): ?>
            <?php while($fila = $resultado->fetch_assoc()): // Recorre cada intercambio ?>
                <?php // Si el intercambio está aceptado, no se muestra en la lista pública
            if ($fila['estado'] === 'aceptado') {
        continue; // No mostrar intercambios aceptados en la lista pública
    } else {
                        // Estado visual para mostrar que el intercambio está pendiente
                $estado = '<span class="badge bg-warning text-dark">Pendiente</span>';
    }?>
  <div class="modern-card">
    <div class="d-flex flex-wrap align-items-center justify-content-between mb-2">
      <span class="usuario-nombre"><i class="bi bi-person-circle me-1"></i><?php echo htmlspecialchars($fila["usuario"]); ?></span>
      <span class="fecha"><i class="bi bi-calendar-event me-1"></i><?php echo date('d/m/Y H:i', strtotime($fila["fecha_creacion"])); ?></span>
    </div>
    <div class="mb-2">
      <span class="modern-label">Ofrece:</span>
      <span class="badge-servicio"><i class="bi bi-gift"></i> <?php echo htmlspecialchars($fila["servicio_ofrecido"]); ?></span>
      <span class="badge-horas"><i class="bi bi-clock-history"></i> <?php echo $fila["horas_ofrecidas"]; ?> hrs</span>
    </div>
    <div class="mb-2">
      <span class="modern-label">A cambio de:</span>
      <span class="badge-servicio" style="background:linear-gradient(90deg,#185a9d,#43cea2);"><i class="bi bi-arrow-repeat"></i> <?php echo htmlspecialchars($fila["servicio_deseado"]); ?></span>
      <span class="badge-horas"><i class="bi bi-clock-history"></i> <?php echo $fila["horas_deseadas"]; ?> hrs</span>
    </div>
    <div class="descripcion"><i class="bi bi-chat-left-text me-1"></i><?php echo htmlspecialchars($fila["descripcion"]); ?></div>
    <div class="modern-actions">
      <a href="/Banco de tiempo/perfil.php?usuario=<?php echo urlencode($fila['usuario']); ?>" target="_blank" class="btn btn-anim btn-ver-perfil"><i class="bi bi-person-circle"></i> Ver Perfil</a>
      <button class="btn btn-anim btn-reportar" onclick="abrirModalReporte('<?php echo htmlspecialchars($fila['usuario']); ?>')"><i class="bi bi-flag"></i> Reportar</button>
      <button class="btn btn-success" onclick="alert('Has aceptado esta oferta. ¡Nos pondremos en contacto contigo!')"><i class="bi bi-hand-thumbs-up"></i> Aceptar</button>
    </div>
  </div>
<?php endwhile; ?>
    <?php else: ?>
    <div class="alert alert-info text-center">No hay intercambios registrados aún.</div>
    <?php endif; ?>

    <a href="dashboard.php" class="btn btn-secondary mt-3">Volver al Dashboard</a>
</div>

<!-- Modal Reporte Rápido -->
<div class="modal fade" id="modalReporteRapido" tabindex="-1" aria-labelledby="modalReporteRapidoLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <form method="POST" action="php/enviar_reporte.php">
        <div class="modal-header">
          <h5 class="modal-title" id="modalReporteRapidoLabel">Reportar usuario</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
        </div>
        <div class="modal-body">
          <input type="hidden" name="usuario_reportado" id="usuarioReportadoInput">
          <div class="mb-3">
            <label class="form-label">Motivo del reporte</label>
            <textarea class="form-control" name="motivo" required></textarea>
          </div>
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-danger">Enviar reporte</button>
        </div>
      </form>
    </div>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
function abrirModalReporte(usuario) {
  document.getElementById('usuarioReportadoInput').value = usuario;
  var modal = new bootstrap.Modal(document.getElementById('modalReporteRapido'));
  modal.show();
}
</script>
</body>
</html>
