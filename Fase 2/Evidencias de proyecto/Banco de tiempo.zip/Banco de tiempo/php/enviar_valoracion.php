<?php
// =========================================
// Script para enviar una valoración de intercambio
// Valida sesión, inserta la valoración y maneja errores
// =========================================

// Inicia la sesión para obtener el usuario actual
session_start();

// Incluye la configuración de la base de datos
include('db_config.php');

// Establece el tipo de contenido de la respuesta en JSON
header('Content-Type: application/json');

// Verifica si el usuario ha iniciado sesión
if (!isset($_SESSION['usuario'])) {
    // Si no ha iniciado sesión, devuelve un código de respuesta 403 (Forbidden)
    http_response_code(403);
    exit;
}

// Obtiene el usuario actual desde la sesión
$evaluador = $_SESSION['usuario'];

// Obtiene el ID del intercambio desde la solicitud POST
$intercambio_id = intval($_POST['intercambio_id'] ?? 0);

// Obtiene el nombre del evaluado desde la solicitud POST
$evaluado = $_POST['evaluado'] ?? '';

// Obtiene la puntuación desde la solicitud POST
$puntuacion = intval($_POST['puntuacion'] ?? 0);
$comentario = trim($_POST['comentario'] ?? '');
if ($intercambio_id <= 0 || !$evaluado || $puntuacion < 1 || $puntuacion > 5) {
    echo json_encode(['success'=>false, 'error'=>'Datos incompletos']);
    exit;
}
$stmt = $conn->prepare('INSERT INTO valoraciones (intercambio_id, evaluador, evaluado, puntuacion, comentario) VALUES (?, ?, ?, ?, ?)');
$stmt->bind_param('issis', $intercambio_id, $evaluador, $evaluado, $puntuacion, $comentario);
$ok = $stmt->execute();
$stmt->close();
$conn->close();
echo json_encode(['success'=>$ok]);
