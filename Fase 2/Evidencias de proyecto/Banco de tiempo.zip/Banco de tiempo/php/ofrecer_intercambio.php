<?php
// =========================================
// Script para ofrecer un nuevo intercambio
// Valida sesión, inserta el intercambio y maneja errores
// =========================================

// Inicia la sesión para obtener el usuario actual
session_start();

// Incluye la configuración de la base de datos
include('db_config.php');

// Establece el tipo de contenido de la respuesta en JSON
header('Content-Type: application/json');

// Verifica si se ha enviado un formulario mediante el método POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Obtiene el usuario actual de la sesión
    $usuario = $_SESSION["usuario"];

    // Obtiene los datos del formulario
    $servicio = $_POST["servicio"];
    $horas_ofrecidas = $_POST["horas_ofrecidas"];
    $horas_deseadas = $_POST["horas_deseadas"];
    $servicio_cambio = $_POST["servicio_cambio"];
    $descripcion = $_POST["descripcion"];

    $sql = "INSERT INTO intercambios (usuario, servicio_ofrecido, horas_ofrecidas, horas_deseadas, servicio_deseado, descripcion) 
            VALUES ('$usuario', '$servicio', '$horas_ofrecidas', '$horas_deseadas', '$servicio_cambio', '$descripcion')";

    if ($conn->query($sql) === TRUE) {
        header("Location: ../dashboard.php?mensaje=Oferta realizada correctamente");
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
?>
