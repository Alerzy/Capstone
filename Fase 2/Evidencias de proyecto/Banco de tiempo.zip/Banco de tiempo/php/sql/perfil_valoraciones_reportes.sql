-- 1. Tabla para valoraciones y comentarios post-intercambio
CREATE TABLE IF NOT EXISTS valoraciones (
    id INT AUTO_INCREMENT PRIMARY KEY,
    intercambio_id INT NOT NULL,
    evaluador VARCHAR(50) NOT NULL,
    evaluado VARCHAR(50) NOT NULL,
    puntuacion TINYINT NOT NULL CHECK (puntuacion BETWEEN 1 AND 5),
    comentario TEXT,
    fecha DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (intercambio_id) REFERENCES intercambios(id)
);

-- 2. Tabla para reportes de usuarios/intercambios
CREATE TABLE IF NOT EXISTS reportes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    reportante VARCHAR(50) NOT NULL,
    usuario_reportado VARCHAR(50),
    intercambio_id INT,
    motivo TEXT NOT NULL,
    fecha DATETIME DEFAULT CURRENT_TIMESTAMP
);
