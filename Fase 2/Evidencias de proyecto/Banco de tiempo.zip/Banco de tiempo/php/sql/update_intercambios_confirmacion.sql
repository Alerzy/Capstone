ALTER TABLE intercambios 
ADD COLUMN confirmado_por_ofertante TINYINT(1) NOT NULL DEFAULT 0,
ADD COLUMN confirmado_por_aceptante TINYINT(1) NOT NULL DEFAULT 0;
