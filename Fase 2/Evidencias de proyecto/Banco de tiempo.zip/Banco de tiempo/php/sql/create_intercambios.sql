DROP TABLE IF EXISTS intercambios;

CREATE TABLE intercambios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario VARCHAR(100) NOT NULL,
    servicio_ofrecido VARCHAR(100) NOT NULL,
    horas_ofrecidas INT NOT NULL,
    horas_deseadas INT NOT NULL,
    servicio_deseado VARCHAR(100) NOT NULL,
    descripcion TEXT,
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
