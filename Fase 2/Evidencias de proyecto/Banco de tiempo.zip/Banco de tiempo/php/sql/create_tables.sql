-- Crear base de datos
CREATE DATABASE IF NOT EXISTS banco_tiempo CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE banco_tiempo;

-- Crear tabla de usuarios
CREATE TABLE IF NOT EXISTS usuarios (
  id INT AUTO_INCREMENT PRIMARY KEY,
  usuario VARCHAR(100) NOT NULL,
  contrasena VARCHAR(255) NOT NULL
);

-- Crear tabla de intercambios
CREATE TABLE IF NOT EXISTS intercambios (
  id INT AUTO_INCREMENT PRIMARY KEY,
  usuario_id INT NOT NULL,
  servicio VARCHAR(255) NOT NULL,
  descripcion TEXT NOT NULL,
  fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);
