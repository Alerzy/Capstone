ALTER TABLE usuarios ADD COLUMN horas_disponibles INT NOT NULL DEFAULT 0;
