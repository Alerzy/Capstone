-- Agrega campos para control de cambio de nombre
ALTER TABLE usuarios 
  ADD COLUMN ultimo_cambio_nombre DATETIME DEFAULT NULL,
  ADD COLUMN cambios_nombre INT DEFAULT 0;
