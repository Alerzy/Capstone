
<?php
// =========================================
// Script para verificar si hay sesión activa
// Redirige a inicio si no hay usuario logueado
// =========================================

// Inicia la sesión para acceder a las variables de sesión
session_start();

// Verifica si existe una variable de sesión 'user_id' para determinar si hay un usuario logueado
if (!isset($_SESSION['user_id'])) {
    // Si no hay usuario logueado, redirige a la página de inicio con un parámetro de error
    header("Location: ../index.php");
    // Finaliza la ejecución del script para evitar acceso no autorizado
    exit();
}
?>
