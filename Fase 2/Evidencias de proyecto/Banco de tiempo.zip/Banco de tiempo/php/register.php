<?php
// =========================================
// Script de Registro de Usuario
// Valida datos, inserta nuevo usuario y maneja errores
// =========================================

// Conexión a la base de datos
include("db_config.php");

// Si se envió el formulario por POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Normaliza el usuario a minúsculas y limpia los datos
    $usuario = strtolower($_POST["usuario"]);
    $contrasena = $_POST["contrasena"];
    $hash = password_hash($contrasena, PASSWORD_DEFAULT);
    $horas_iniciales = 5;

    // Verificar si el usuario ya existe
    // Prepara la consulta para verificar la existencia del usuario
    $check = $conn->prepare("SELECT usuario FROM usuarios WHERE usuario = ?");
    $check->bind_param("s", $usuario);
    $check->execute();
    $check->store_result();
    // Si el usuario ya existe, redirige con error
    if ($check->num_rows > 0) {
        $check->close();
        $conn->close();
        // Redirige de vuelta al registro con error
        header("Location: ../register.php?error=usuario");
        exit();
    }
    $check->close();

    // Inserta el nuevo usuario en la base de datos
    // Prepara la consulta para insertar el nuevo usuario
    $stmt = $conn->prepare("INSERT INTO usuarios (usuario, contrasena, horas_disponibles) VALUES (?, ?, ?)");
    $stmt->bind_param("ssi", $usuario, $hash, $horas_iniciales);
    $stmt->execute();
    $stmt->close();
    $conn->close();

    // Registro exitoso, redirige al inicio
    header("Location: ../index.php");
    exit();
}
?>
