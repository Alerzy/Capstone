<?php
// =========================================
// Script de Login de Usuario
// Valida credenciales, inicia sesión y redirige según el rol
// =========================================

include('db_config.php'); // Conexión a la base de datos

session_start(); // Inicia o reanuda la sesión

// Si se envió el formulario por POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Normaliza el usuario a minúsculas y obtiene la contraseña
    $usuario = strtolower($_POST['usuario']);
    $contrasena = $_POST['contrasena'];

    // Consulta la contraseña hasheada del usuario
    $stmt = $conn->prepare("SELECT contrasena FROM usuarios WHERE usuario = ?");
    $stmt->bind_param("s", $usuario);
    $stmt->execute();
    $stmt->bind_result($hash);
    // Si el usuario existe y la contraseña es correcta
    if ($stmt->fetch() && password_verify($contrasena, $hash)) {
        // Guarda el usuario en la sesión
        $_SESSION['usuario'] = $usuario;
        $stmt->close();
        // Verifica si el usuario es administrador
        $stmt2 = $conn->prepare("SELECT es_admin FROM usuarios WHERE usuario=?");
        $stmt2->bind_param("s", $usuario);
        $stmt2->execute();
        $stmt2->bind_result($es_admin);
        $stmt2->fetch();
        $stmt2->close();
        $conn->close();
        // Redirige según el rol
        if ($es_admin || $usuario === 'solis') {
            // Si es admin o solis, va al panel admin
            header("Location: ../admin.php");
        } else {
            // Usuario normal va al dashboard
            header("Location: ../dashboard.php");
        }
        exit();
    } else {
        // Si el usuario o contraseña no coinciden
        $stmt->close();
        $conn->close();
        header("Location: ../index.php?error=contrasena");
        exit();
    }
}
?>
