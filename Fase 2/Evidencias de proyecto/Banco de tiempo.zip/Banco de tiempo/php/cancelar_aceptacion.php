<?php
// =========================================
// Script para cancelar la aceptación de un intercambio
// Valida sesión, usuario, estado y actualiza el intercambio
// =========================================

// Inicia la sesión para obtener el usuario autenticado
session_start();

// Establece el tipo de contenido de la respuesta en JSON
header('Content-Type: application/json');

// Incluye la configuración de la base de datos
include 'db_config.php';

// Verifica si el usuario está autenticado
if (!isset($_SESSION['usuario'])) {
    // Si no está autenticado, devuelve un error en formato JSON
    echo json_encode(['success' => false, 'error' => 'No autenticado']);
    exit;
}

// Obtiene el usuario autenticado y el ID del intercambio
$usuario = $conn->real_escape_string($_SESSION['usuario']);
$id = isset($_POST['id']) ? intval($_POST['id']) : 0;
if ($id <= 0) {
    echo json_encode(['success' => false, 'error' => 'ID inválido']);
    exit;
}
$res = $conn->query("SELECT * FROM intercambios WHERE id=$id");
$inter = $res->fetch_assoc();
if (!$inter) {
    echo json_encode(['success' => false, 'error' => 'No existe el intercambio']);
    exit;
}
if ($inter['estado'] !== 'aceptado') {
    echo json_encode(['success' => false, 'error' => 'El intercambio no está aceptado']);
    exit;
}
if (strtolower($inter['aceptado_por']) !== strtolower($usuario)) {
    echo json_encode(['success' => false, 'error' => 'No autorizado']);
    exit;
}
// Restablecer el intercambio a pendiente
$stmt = $conn->prepare("UPDATE intercambios SET estado='pendiente', aceptado_por=NULL, confirmado_por_ofertante=0, confirmado_por_aceptante=0 WHERE id=? AND aceptado_por=? AND estado='aceptado'");
$stmt->bind_param('ii', $id, $usuario);

// Notificar al ofertante
$stmt2 = $conn->prepare("SELECT usuario FROM intercambios WHERE id=?");
$stmt2->bind_param('i', $id);
$stmt2->execute();
$stmt2->bind_result($ofertante);
if ($stmt2->fetch() && $ofertante !== $usuario) {
    $mensaje = "El usuario $usuario ha cancelado la aceptación de tu intercambio.";
    $stmt2->close(); // Cierra antes de usar $conn de nuevo
    $stmt3 = $conn->prepare("INSERT INTO notificaciones (usuario_destino, mensaje) VALUES (?, ?)");
    $stmt3->bind_param('ss', $ofertante, $mensaje);
    $stmt3->execute();
    $stmt3->close();
} else {
    $stmt2->close();
}
try {
    if ($stmt->execute() === TRUE) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => $conn->error]);
    }
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
$stmt->close();
if (isset($stmt3)) $stmt3->close();
$conn->close();
