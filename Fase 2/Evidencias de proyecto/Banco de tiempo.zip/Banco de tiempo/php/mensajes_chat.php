<?php
// =========================================
// Script para obtener mensajes del chat de un intercambio
// Valida sesión, consulta y retorna mensajes en JSON
// =========================================

// Inicia la sesión para obtener datos del usuario
session_start();

// Incluye la configuración de la base de datos
include('db_config.php');

// Establece el tipo de contenido de la respuesta en JSON
header('Content-Type: application/json');

// Verifica si el usuario ha iniciado sesión
if (!isset($_SESSION['usuario'])) {
    // Si no ha iniciado sesión, devuelve un código de respuesta 403 (Forbidden)
    http_response_code(403);
    exit;
}

// Obtiene el nombre de usuario de la sesión y lo escapa para evitar inyección SQL
$usuario = $conn->real_escape_string($_SESSION['usuario']);

// Obtiene el ID del intercambio desde la URL, si no existe, se establece en 0
$intercambio_id = isset($_GET['intercambio_id']) ? intval($_GET['intercambio_id']) : 0;

// Verifica si el ID del intercambio es válido (mayor que 0)
if ($intercambio_id <= 0) {
    // Si no es válido, devuelve un arreglo vacío en JSON
    echo json_encode([]);
    exit;
}
$sql = "SELECT * FROM mensajes WHERE intercambio_id=$intercambio_id ORDER BY fecha ASC";
$resultado = $conn->query($sql);
$mensajes = array();
while ($fila = $resultado->fetch_assoc()) {
    $mensajes[] = $fila;
}
header('Content-Type: application/json');
echo json_encode($mensajes);
$conn->close();
