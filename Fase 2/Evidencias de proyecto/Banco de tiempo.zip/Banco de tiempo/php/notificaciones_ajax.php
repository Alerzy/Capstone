<?php
// =========================================
// Script para consultar notificaciones por AJAX
// Valida sesión, consulta y retorna notificaciones
// =========================================

// Inicia la sesión para validar al usuario
session_start();

// Verifica si el usuario está autorizado
if (!isset($_SESSION['usuario'])) {
    // Si no está autorizado, devuelve un código de respuesta 401 y un mensaje de error
    http_response_code(401);
    echo json_encode(['error' => 'No autorizado']);
    exit;
}

// Incluye el archivo de configuración de la base de datos
require_once 'db_config.php';

// Obtiene el usuario actual de la sesión
$usuario = $_SESSION['usuario'];

// Obtiene la acción solicitada por el usuario (si existe)
$accion = isset($_POST['accion']) ? $_POST['accion'] : '';

if ($accion === 'marcar_leidas') {
    $conn->query("UPDATE notificaciones SET leida=1 WHERE usuario_destino='".$conn->real_escape_string($usuario)."'");
    echo json_encode(['success' => true]);
    exit;
}

// Obtener notificaciones recientes (máx 20, no leídas primero)
$stmt = $conn->prepare("SELECT id, mensaje, leida, fecha FROM notificaciones WHERE usuario_destino=? ORDER BY leida ASC, fecha DESC LIMIT 20");
$stmt->bind_param('s', $usuario);
$stmt->execute();
$res = $stmt->get_result();
$notificaciones = [];
while ($row = $res->fetch_assoc()) {
    $notificaciones[] = $row;
}
echo json_encode(['notificaciones' => $notificaciones]);
