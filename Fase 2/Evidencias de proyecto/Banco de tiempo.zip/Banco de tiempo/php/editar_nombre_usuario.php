<?php
// =========================================
// Script para editar el nombre de usuario
// Valida sesión, tiempo mínimo y actualiza nombre
// =========================================

// Inicia la sesión para obtener el usuario actual
session_start();

// Incluye la configuración de la base de datos
include 'db_config.php';

// Establece el tipo de contenido de la respuesta en JSON
header('Content-Type: application/json');

// Verifica si el usuario está logueado
if (!isset($_SESSION['usuario'])) {
    // Si no está logueado, devuelve un error de autenticación
    echo json_encode(['success'=>false, 'error'=>'No autenticado']);
    exit;
}

// Obtiene el usuario actual de la sesión
$usuario_actual = $_SESSION['usuario'];

// Obtiene el nuevo nombre de usuario desde la solicitud POST
$nuevo_usuario = trim($_POST['nuevo_usuario'] ?? '');

// Verifica si el nuevo nombre de usuario es válido (no vacío y al menos 3 caracteres)
if (!$nuevo_usuario || strlen($nuevo_usuario) < 3) {
    // Si no es válido, devuelve un error de validación
    echo json_encode(['success'=>false, 'error'=>'El nombre debe tener al menos 3 caracteres.']);
    exit;
}
// Verifica si ya existe ese nombre
$stmt = $conn->prepare('SELECT usuario FROM usuarios WHERE usuario=?');
$stmt->bind_param('s', $nuevo_usuario);
$stmt->execute();
$stmt->store_result();
if ($stmt->num_rows > 0) {
    echo json_encode(['success'=>false, 'error'=>'Nombre de usuario ya en uso.']);
    exit;
}
$stmt->close();
// Verifica política de 1 mes
$stmt = $conn->prepare('SELECT ultimo_cambio_nombre FROM usuarios WHERE usuario=?');
$stmt->bind_param('s', $usuario_actual);
$stmt->execute();
$stmt->bind_result($ultimo);
$stmt->fetch();
$stmt->close();
$ahora = new DateTime();
if (!empty($ultimo) && !($ultimo instanceof DateTime)) {
    $ultimo_dt = new DateTime($ultimo);
} else {
    $ultimo_dt = null;
}
if ($ultimo_dt && $ahora->diff($ultimo_dt)->m < 1 && $ahora->diff($ultimo_dt)->days < 30) {
    $dias = 30 - $ahora->diff($ultimo_dt)->days;
    echo json_encode(['success'=>false, 'error'=>'Debes esperar '.$dias.' día(s) para volver a cambiar tu nombre.']);
    exit;
}
// Realiza el cambio
$stmt = $conn->prepare('UPDATE usuarios SET usuario=?, ultimo_cambio_nombre=NOW(), cambios_nombre = cambios_nombre + 1 WHERE usuario=?');
$stmt->bind_param('ss', $nuevo_usuario, $usuario_actual);
if ($stmt->execute()) {
    $_SESSION['usuario'] = $nuevo_usuario;
    echo json_encode(['success'=>true, 'nuevo_usuario'=>$nuevo_usuario]);
} else {
    echo json_encode(['success'=>false, 'error'=>'Error al actualizar.']);
}
$stmt->close();
$conn->close();
