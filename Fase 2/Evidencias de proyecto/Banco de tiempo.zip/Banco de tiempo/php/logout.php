<?php
// =========================================
// Script para cerrar sesión de usuario
// Destruye la sesión y redirige al inicio
// =========================================

session_start(); // Inicia la sesión para poder destruirla
session_unset(); // Elimina todas las variables de sesión
session_destroy(); // Destruye la sesión
header('Location: ../index.php'); // Redirige al inicio
exit();
?>
