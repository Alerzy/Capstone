<?php
// =========================================
// Script para eliminar un intercambio
// Valida sesión, usuario y elimina el intercambio
// =========================================

// Inicia la sesión para obtener el usuario autenticado
session_start();

// Incluye la configuración de la base de datos
include 'db_config.php';

// Establece el tipo de contenido de la respuesta en JSON
header('Content-Type: application/json');

// Verifica si el usuario está autenticado
if (!isset($_SESSION['usuario'])) {
    // Si no está autenticado, devuelve un error en formato JSON
    echo json_encode(['success' => false, 'error' => 'No autenticado']);
    exit;
}

// Obtiene el ID del intercambio a eliminar
$usuario = $conn->real_escape_string($_SESSION['usuario']);
$id = isset($_POST['id']) ? intval($_POST['id']) : 0;
if ($id <= 0) {
    echo json_encode(['success' => false, 'error' => 'ID inválido']);
    exit;
}
$sql = "DELETE FROM intercambios WHERE id=$id AND usuario='$usuario'";
if ($conn->query($sql) === TRUE) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'error' => $conn->error]);
}
$conn->close();
