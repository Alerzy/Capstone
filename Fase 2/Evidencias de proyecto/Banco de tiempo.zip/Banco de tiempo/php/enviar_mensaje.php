<?php
// =========================================
// Script para enviar un mensaje en el chat
// Valida sesión, inserta el mensaje y maneja errores
// =========================================

// Inicia la sesión para obtener el usuario actual
session_start();

// Incluye la configuración de la base de datos
include 'db_config.php';

// Establece el tipo de contenido de la respuesta en JSON
header('Content-Type: application/json');

// Verifica si el usuario ha iniciado sesión
if (!isset($_SESSION['usuario'])) {
    // Si no ha iniciado sesión, devuelve un código de respuesta 403 (Forbidden)
    http_response_code(403);
    exit;
}

// Obtiene el usuario actual y lo escapa para evitar inyección SQL
$usuario = $conn->real_escape_string($_SESSION['usuario']);

// Obtiene el ID del intercambio y lo convierte a entero
$intercambio_id = isset($_POST['intercambio_id']) ? intval($_POST['intercambio_id']) : 0;

// Obtiene el receptor y el mensaje del formulario
$receptor = $conn->real_escape_string($_POST['receptor']);
$mensaje = $conn->real_escape_string($_POST['mensaje']);
if ($intercambio_id <= 0 || empty($receptor) || empty($mensaje)) {
    echo json_encode(['success'=>false]);
    exit;
}
$sql = "INSERT INTO mensajes (intercambio_id, emisor, receptor, mensaje) VALUES ($intercambio_id, '$usuario', '$receptor', '$mensaje')";
$ok = $conn->query($sql);
if ($receptor !== $usuario) {
    // Notificación con enlace especial para abrir chat desde el dashboard
    $mensajeNotif = "<span class='chat-noti' data-intercambio='$intercambio_id' data-receptor='$emisor'>Nuevo mensaje de <strong>$usuario</strong> en el chat</span>";
    $stmtN = $conn->prepare("INSERT INTO notificaciones (usuario_destino, mensaje) VALUES (?, ?)");
    $stmtN->bind_param('ss', $receptor, $mensajeNotif);
    $stmtN->execute();
    $stmtN->close();
}
echo json_encode(['success'=>$ok]);
$conn->close();
