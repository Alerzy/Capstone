<?php
// =========================================
// Configuración de conexión a la base de datos
// =========================================

$host = 'localhost'; // Servidor de base de datos
$user = 'root';      // Usuario de la base de datos
$pass = '';          // Contraseña de la base de datos
$db = 'banco_tiempo'; // Nombre de la base de datos

// Crea la conexión usando MySQLi
$conn = new mysqli($host, $user, $pass, $db);

// Verifica si hay errores de conexión
if ($conn->connect_error) {
    die('Error de conexión: ' . $conn->connect_error);
}
?>
