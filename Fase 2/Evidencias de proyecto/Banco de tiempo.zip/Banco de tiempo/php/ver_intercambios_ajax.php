<?php
// =========================================
// Script para consultar intercambios vía AJAX
// Valida sesión, consulta y retorna datos en JSON
// =========================================

// Inicia sesión y carga configuración de la base de datos
session_start();
include('db_config.php');

// Establece el tipo de contenido de la respuesta en JSON
header('Content-Type: application/json');

// Verifica si se ha enviado un ID de intercambio vía GET
if (isset($_GET['id'])) {
    // Obtiene el ID de intercambio y lo convierte a entero
    $id = intval($_GET['id']);
    
    // Consulta el intercambio con el ID especificado
    $sql = "SELECT * FROM intercambios WHERE id = $id LIMIT 1";
    $res = $conn->query($sql);
    
    // Obtiene la fila de resultado de la consulta
    $fila = $res ? $res->fetch_assoc() : null;
    
    // Retorna el resultado en formato JSON
    echo json_encode($fila ? [$fila] : []);
    $conn->close();
    exit;
}
// Por defecto, solo pendientes
$sql = "SELECT * FROM intercambios WHERE estado = 'pendiente' ORDER BY id DESC";
$resultado = $conn->query($sql);
$intercambios = array();
while ($fila = $resultado->fetch_assoc()) {
    $intercambios[] = $fila;
}
echo json_encode($intercambios);

$conn->close();
?>
