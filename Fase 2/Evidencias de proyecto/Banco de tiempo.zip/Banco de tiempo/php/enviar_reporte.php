<?php
// =========================================
// Script para enviar un reporte de usuario/intercambio
// Valida sesión, inserta el reporte y maneja errores
// =========================================

// Inicia la sesión para obtener datos del usuario
session_start();

// Incluye la configuración de la base de datos
include('db_config.php');

// Verifica si el usuario está logueado
if (!isset($_SESSION['usuario'])) {
    // Si no está logueado, redirige a la página de inicio
    header('Location: ../index.php');
    exit();
}

// Obtiene el nombre del usuario que está reportando
$reportante = $_SESSION['usuario'];

// Obtiene el nombre del usuario reportado y el ID del intercambio (si aplica)
$usuario_reportado = $_POST['usuario_reportado'] ?? '';
$intercambio_id = isset($_POST['intercambio_id']) ? intval($_POST['intercambio_id']) : null;
$motivo = trim($_POST['motivo'] ?? '');
if (!$usuario_reportado && !$intercambio_id) {
    echo '<script>alert("Faltan datos para el reporte.");history.back();</script>';
    exit();
}
$stmt = $conn->prepare('INSERT INTO reportes (reportante, usuario_reportado, intercambio_id, motivo) VALUES (?, ?, ?, ?)');
$stmt->bind_param('ssis', $reportante, $usuario_reportado, $intercambio_id, $motivo);
$stmt->execute();
$stmt->close();
$conn->close();
echo '<script>alert("Reporte enviado. Gracias por ayudarnos a mejorar la comunidad.");window.location="../perfil.php?usuario='.urlencode($usuario_reportado).'";</script>';
