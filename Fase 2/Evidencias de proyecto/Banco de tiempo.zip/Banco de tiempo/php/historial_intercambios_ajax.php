<?php
// =========================================
// Script para consultar el historial de intercambios vía AJAX
// Valida sesión, determina el tipo de historial, ejecuta la consulta y retorna datos en JSON
// =========================================
// Inicia la sesión para acceder al usuario autenticado
session_start();
// Verifica si el usuario está autenticado
if (!isset($_SESSION['usuario'])) {
    http_response_code(403);
    echo json_encode(["error" => "No autenticado"]);
    exit;
}
// Incluye la configuración de la base de datos
include 'db_config.php';
// Obtiene el nombre del usuario autenticado y lo escapa para SQL
$usuario = $conn->real_escape_string($_SESSION['usuario']);
// Obtiene el tipo de historial solicitado (publicados, aceptados, me_aceptaron)
$tipo = isset($_GET['tipo']) ? $_GET['tipo'] : '';

// Inicializa la variable para la consulta SQL
$sql = "";
// Determina la consulta SQL según el tipo de historial solicitado
if ($tipo === 'publicados') {
    $sql = "SELECT i.*, 
        (SELECT 1 FROM valoraciones v WHERE v.intercambio_id = i.id AND v.evaluador = '$usuario' LIMIT 1) AS valorado_por_mi,
        (SELECT 1 FROM valoraciones v WHERE v.intercambio_id = i.id AND v.evaluador = i.usuario LIMIT 1) AS valoracion_ofertante,
        (SELECT 1 FROM valoraciones v WHERE v.intercambio_id = i.id AND v.evaluador = i.aceptado_por LIMIT 1) AS valoracion_aceptante
    FROM intercambios i WHERE i.usuario='$usuario' ORDER BY i.fecha_creacion DESC";
} elseif ($tipo === 'aceptados') {
    // Intercambios en los que el usuario fue aceptado
    $sql = "SELECT i.*, 
        (SELECT 1 FROM valoraciones v WHERE v.intercambio_id = i.id AND v.evaluador = '$usuario' LIMIT 1) AS valorado_por_mi,
        (SELECT 1 FROM valoraciones v WHERE v.intercambio_id = i.id AND v.evaluador = i.usuario LIMIT 1) AS valoracion_ofertante,
        (SELECT 1 FROM valoraciones v WHERE v.intercambio_id = i.id AND v.evaluador = i.aceptado_por LIMIT 1) AS valoracion_aceptante
    FROM intercambios i WHERE i.aceptado_por='$usuario' ORDER BY i.fecha_creacion DESC";
} elseif ($tipo === 'me_aceptaron') {
    // Intercambios publicados por el usuario y que fueron aceptados
    $sql = "SELECT i.*, 
        (SELECT 1 FROM valoraciones v WHERE v.intercambio_id = i.id AND v.evaluador = '$usuario' LIMIT 1) AS valorado_por_mi,
        (SELECT 1 FROM valoraciones v WHERE v.intercambio_id = i.id AND v.evaluador = i.usuario LIMIT 1) AS valoracion_ofertante,
        (SELECT 1 FROM valoraciones v WHERE v.intercambio_id = i.id AND v.evaluador = i.aceptado_por LIMIT 1) AS valoracion_aceptante
    FROM intercambios i WHERE i.usuario='$usuario' AND i.estado='aceptado' ORDER BY i.fecha_creacion DESC";
} else {
    // Si no se especifica un tipo válido, devuelve un arreglo vacío
    echo json_encode([]);
    exit;
}

// Ejecuta la consulta SQL para obtener los intercambios
$resultado = $conn->query($sql);

// Inicializa un arreglo para almacenar los resultados de los intercambios
$intercambios = array();

// Recorre los resultados de la consulta y agrega cada intercambio al arreglo
while ($fila = $resultado->fetch_assoc()) {
    $intercambios[] = $fila;
}

// Establece el tipo de contenido de la respuesta como JSON
header('Content-Type: application/json');

// Devuelve el arreglo de intercambios en formato JSON
echo json_encode($intercambios);

// Cierra la conexión con la base de datos
$conn->close();
