<?php
// =========================================
// Script para listar usuarios (solo admin)
// Valida sesión y permisos, consulta y retorna usuarios
// =========================================

// Inicia la sesión para obtener el usuario actual
session_start();

// Incluye la configuración de la base de datos
include('db_config.php');

// Establece el tipo de contenido de la respuesta en JSON
header('Content-Type: application/json');

// Verifica si el usuario está autenticado
if (!isset($_SESSION['usuario'])) {
    // Si no está autenticado, retorna un error en formato JSON
    echo json_encode(['success'=>false,'error'=>'No autenticado']);
    exit;
}

// Obtiene el usuario actual de la sesión
$usuario = $_SESSION['usuario'];

// Prepara la consulta para verificar si el usuario es administrador
$stmt = $conn->prepare('SELECT es_admin FROM usuarios WHERE usuario=?');
$stmt->bind_param('s', $usuario);
$stmt->execute();
$stmt->bind_result($es_admin);
$stmt->fetch();
$stmt->close();
if (!$es_admin && strtolower($usuario) !== 'solis') {
    echo json_encode(['success'=>false,'error'=>'No autorizado']);
    exit;
}
$res = $conn->query('SELECT usuario, horas_disponibles, es_admin FROM usuarios ORDER BY usuario');
$usuarios = [];
while ($row = $res->fetch_assoc()) {
    $usuarios[] = $row;
}
echo json_encode(['success'=>true,'usuarios'=>$usuarios]);
$conn->close();
