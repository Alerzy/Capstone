<?php
// =========================================
// Script para aceptar un intercambio
// Valida sesión, usuario y actualiza el estado del intercambio
// =========================================

// Inicia la sesión para obtener información del usuario
session_start();

// Verifica si el usuario está logueado
if (!isset($_SESSION['usuario'])) {
    // Si no está logueado, redirige a la página de inicio
    header('Location: ../index.php');
    exit();
}

// Incluye la configuración de la base de datos
include 'db_config.php';

// Obtiene el ID del intercambio desde la URL
$id = intval($_GET['id']);

// Obtiene el nombre de usuario desde la sesión
$usuario = $conn->real_escape_string($_SESSION['usuario']);

// =========================================
// 1. Obtener datos del intercambio
// =========================================
// Consulta la base de datos para obtener información del intercambio
$res = $conn->query("SELECT * FROM intercambios WHERE id=$id");
$inter = $res->fetch_assoc();
if (!$inter) {
    echo "<script>alert('Intercambio no encontrado'); window.location.href = '../dashboard.php';</script>";
    exit;
}
if ($inter['estado'] === 'aceptado') {
    echo "<script>alert('Este intercambio ya fue aceptado'); window.location.href = '../dashboard.php';</script>";
    exit;
}
$ofertante = $inter['usuario'];
$horas = intval($inter['horas_ofrecidas']);

// 2. Verificar saldo del aceptador
$res2 = $conn->query("SELECT horas_disponibles FROM usuarios WHERE usuario='$usuario'");
$u = $res2->fetch_assoc();
if ($u['horas_disponibles'] < $horas) {
    echo "<script>alert('No tienes suficientes horas para aceptar este intercambio.'); window.location.href = '../dashboard.php';</script>";
    exit;
}

// Marcar como aceptado por el usuario actual
$stmt = $conn->prepare("UPDATE intercambios SET estado='aceptado', aceptado_por=? WHERE id=? AND estado='pendiente'");
$stmt->bind_param('si', $usuario, $id);
$stmt->execute();

if ($stmt->affected_rows > 0) {
    // 2. Solo si se actualizó, busca el ofertante y manda la notificación
    $stmt2 = $conn->prepare("SELECT usuario FROM intercambios WHERE id=?");
    $stmt2->bind_param('i', $id);
    $stmt2->execute();
    $stmt2->bind_result($ofertante_db);
    $hay_ofertante = $stmt2->fetch();
    $stmt2->close();
    if ($hay_ofertante && $ofertante_db !== $usuario) {
        $mensaje = "Tu intercambio ha sido aceptado por $usuario";
        $stmt3 = $conn->prepare("INSERT INTO notificaciones (usuario_destino, mensaje) VALUES (?, ?)");
        $stmt3->bind_param('ss', $ofertante_db, $mensaje);
        $stmt3->execute();
        $stmt3->close();
    }
    echo "<script>alert('Intercambio aceptado correctamente'); window.location.href = '../dashboard.php';</script>";
} else {
    echo "<script>alert('No se pudo aceptar el intercambio. Puede que ya haya sido aceptado por otro usuario.'); window.location.href = '../dashboard.php';</script>";
}
$stmt->close();
$conn->close();
?>