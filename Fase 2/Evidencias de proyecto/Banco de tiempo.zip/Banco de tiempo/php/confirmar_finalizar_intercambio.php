<?php
// =========================================
// Script para confirmar y finalizar un intercambio
// Valida sesión, usuario, actualiza estado y transfiere horas
// =========================================

// Inicia la sesión para obtener el usuario autenticado
session_start();

// Incluye la configuración de la base de datos
include 'db_config.php';

// Establece el tipo de contenido de la respuesta en JSON
header('Content-Type: application/json');

// Verifica si el usuario está autenticado
if (!isset($_SESSION['usuario'])) {
    // Si no está autenticado, devuelve un error en formato JSON
    echo json_encode(['success' => false, 'error' => 'No autenticado']);
    exit;
}

// Obtiene el ID del intercambio desde la solicitud POST
$usuario = $conn->real_escape_string($_SESSION['usuario']);
$id = isset($_POST['id']) ? intval($_POST['id']) : 0;
if ($id <= 0) {
    echo json_encode(['success' => false, 'error' => 'ID inválido']);
    exit;
}
// Obtener el intercambio
$res = $conn->query("SELECT * FROM intercambios WHERE id=$id");
$inter = $res->fetch_assoc();
if (!$inter) {
    echo json_encode(['success' => false, 'error' => 'No existe el intercambio']);
    exit;
}
if ($inter['estado'] !== 'aceptado') {
    echo json_encode(['success' => false, 'error' => 'El intercambio no está aceptado']);
    exit;
}
// Determinar si el usuario es ofertante o aceptante
$ofertante = $inter['usuario'];
$aceptante = $inter['aceptado_por'];
$confirmado_ofertante = $inter['confirmado_por_ofertante'];
$confirmado_aceptante = $inter['confirmado_por_aceptante'];
$horas = (int)$inter['horas_ofrecidas'];
// Confirmar finalización por el usuario correspondiente
if ($ofertante === $usuario || $aceptante === $usuario) {
    if ($ofertante === $usuario) {
        $stmt = $conn->prepare("UPDATE intercambios SET confirmado_por_ofertante=1 WHERE id=?");
        $stmt->bind_param('i', $id);
        // Notificar al aceptante que el ofertante confirmó
        if ($aceptante) {
            $mensaje = "El usuario $ofertante ha confirmado la finalización del intercambio.";
            $stmtN = $conn->prepare("INSERT INTO notificaciones (usuario_destino, mensaje) VALUES (?, ?)");
            $stmtN->bind_param('ss', $aceptante, $mensaje);
            $stmtN->execute();
            $stmtN->close();
        }
    } else {
        $stmt = $conn->prepare("UPDATE intercambios SET confirmado_por_aceptante=1 WHERE id=?");
        $stmt->bind_param('i', $id);
        // Notificar al ofertante que el aceptante confirmó
        if ($ofertante) {
            $mensaje = "El usuario $aceptante ha confirmado la finalización del intercambio.";
            $stmtN = $conn->prepare("INSERT INTO notificaciones (usuario_destino, mensaje) VALUES (?, ?)");
            $stmtN->bind_param('ss', $ofertante, $mensaje);
            $stmtN->execute();
            $stmtN->close();
        }
    }
} else {
    echo json_encode(['success' => false, 'error' => 'No autorizado']);
    exit;
}
$stmt->execute();
$stmt->close();
// Volver a leer datos actualizados
$res2 = $conn->query("SELECT confirmado_por_ofertante, confirmado_por_aceptante, estado FROM intercambios WHERE id=$id");
$inter2 = $res2->fetch_assoc();
if ($inter2['confirmado_por_ofertante'] && $inter2['confirmado_por_aceptante'] && $inter2['estado'] !== 'finalizado') {
    // Transferir horas y finalizar
    $conn->query("UPDATE usuarios SET horas_disponibles = horas_disponibles - $horas WHERE usuario='$aceptante'");
    $conn->query("UPDATE usuarios SET horas_disponibles = horas_disponibles + $horas WHERE usuario='$ofertante'");
    $conn->query("UPDATE intercambios SET estado='finalizado' WHERE id=$id");
    echo json_encode(['success' => true, 'finalizado' => true]);
} else {
    echo json_encode(['success' => true, 'finalizado' => false]);
}
$conn->close();
