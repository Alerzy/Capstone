<?php
// ===============================
// Panel de Administración - admin.php
// Protege el acceso solo para administradores
// ===============================
session_start();
if (!isset($_SESSION['usuario'])) {
    // Si no hay sesión, redirige a inicio
    header('Location: index.php');
    exit();
}
include 'php/db_config.php';
$usuario = $_SESSION['usuario'];
// Verifica si el usuario es admin (o 'solis')
$stmt = $conn->prepare('SELECT es_admin FROM usuarios WHERE usuario=?');
$stmt->bind_param('s', $usuario);
$stmt->execute();
$stmt->bind_result($es_admin);
$stmt->fetch();
$stmt->close();
if (!$es_admin && strtolower($usuario) !== 'solis') {
    header('Location: index.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Panel de Administración</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <style>
    /* =============================
       Estilos personalizados admin
       ============================= */
        body {
            background: linear-gradient(135deg, #0d6efd 0%, #6f42c1 100%);
            min-height: 100vh;
        }
        /* Tarjeta principal del panel admin */
        .admin-card {
            background: #fff;
            border-radius: 1.5rem;
            box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.18);
            padding: 2.5rem 2rem;
            margin-top: 4rem;
            animation: fadeIn 1s;
        }
        /* Animación de entrada */
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(40px); }
            to { opacity: 1; transform: translateY(0); }
        }
        /* Barra de título con gradiente y botón de logout */
        .admin-title {
            background: linear-gradient(90deg, #0d6efd 40%, #6f42c1 100%);
            color: #fff;
            padding: 1.2rem 1.5rem 1.2rem 1rem;
            border-radius: 1rem 1rem 0 0;
            box-shadow: 0 2px 8px rgba(13,110,253,0.07);
            display: flex;
            align-items: center;
            justify-content: space-between;
            font-size: 2.2rem;
            letter-spacing: 1px;
        }
        /* Botón cerrar sesión */
        .logout-btn {
            font-size: 1rem;
            padding: 0.45rem 1.2rem;
            border-radius: 2rem;
            border: 2px solid #fff;
            background: rgba(255,255,255,0.09);
            color: #fff;
            transition: background 0.18s, color 0.18s, box-shadow 0.18s;
            box-shadow: 0 2px 8px rgba(244,67,54,0.06);
            font-weight: 500;
        }
        .logout-btn:hover, .logout-btn:focus {
            background: #fff;
            color: #f44336;
            border-color: #f44336;
            box-shadow: 0 4px 18px 0 rgba(244,67,54,0.16);
            text-decoration: none;
        }
        /* Sección de botones y tarjetas admin */
        .admin-section {
            margin-top: 2rem;
        }
        .admin-btn {
            font-size: 1.1rem;
            border-radius: 2rem;
            padding: 0.7rem 2rem;
        }
        /* Tarjetas de función con animación */
        .admin-feature {
            transition: transform 0.2s;
        }
        .admin-feature:hover {
            transform: translateY(-4px) scale(1.03);
            box-shadow: 0 6px 32px 0 rgba(111,66,193,0.13);
        }
    </style>
</head>
<body>
<div class="container d-flex justify-content-center align-items-center" style="min-height:100vh;">
    <div class="admin-card w-100" style="max-width: 540px;">
        <!--
    Barra de título con gradiente y botón de cerrar sesión
    Incluye el título y el botón logout alineado a la derecha
-->
<div class="admin-title mb-4">
    <span><i class="bi bi-shield-lock-fill me-2"></i>Panel de Administración</span>
    <a href="php/logout.php" class="logout-btn ms-2 d-flex align-items-center gap-2" data-bs-toggle="tooltip" title="Cerrar sesión y salir">
        <i class="bi bi-box-arrow-right"></i> <span class="d-none d-md-inline">Cerrar sesión</span>
    </a>
</div>
        <!-- Saludo de bienvenida al admin -->
        <div class="text-center mb-3">
            <img src="https://cdn-icons-png.flaticon.com/512/3135/3135715.png" alt="Admin" width="80" class="mb-2" style="filter: drop-shadow(0 2px 6px #0d6efd55);">
            <h4 class="fw-bold mb-0">¡Bienvenido, <span class="text-primary"><?php echo htmlspecialchars($usuario); ?></span>!</h4>
            <small class="text-secondary">Tienes acceso exclusivo de administrador.</small>
        </div>
        <!-- Sección de acciones principales del admin -->
        <div class="admin-section">
            <div class="row g-3">
                <!-- Botón para mostrar usuarios registrados (modal dinámico) -->
                <div class="col-12">
                    <a href="#" id="verUsuariosBtn" class="admin-feature card card-body d-flex flex-row align-items-center gap-3 text-decoration-none">
                        <i class="bi bi-people-fill text-primary fs-3"></i>
                        <span class="fs-5">Ver Panel de Usuarios</span>
                    </a>
                </div>
                <!-- Gestión de usuarios (próximamente) -->
                <div class="col-12">
                    <a href="#" class="admin-feature card card-body d-flex flex-row align-items-center gap-3 text-decoration-none disabled" tabindex="-1">
                        <i class="bi bi-person-gear text-warning fs-3"></i>
                        <span class="fs-5">Gestión de usuarios <span class="badge bg-warning text-dark ms-2">Próximamente</span></span>
                    </a>
                </div>
                <!-- Reportes (próximamente) -->
                <div class="col-12">
                    <a href="#" class="admin-feature card card-body d-flex flex-row align-items-center gap-3 text-decoration-none disabled" tabindex="-1">
                        <i class="bi bi-clipboard-data text-success fs-3"></i>
                        <span class="fs-5">Ver reportes <span class="badge bg-success ms-2">Próximamente</span></span>
                    </a>
                </div>
            </div>
        </div>
        <!-- Botón para regresar al dashboard de usuario -->
        <div class="text-center mt-4">
            <a href="dashboard.php" class="btn btn-outline-primary admin-btn"><i class="bi bi-arrow-left"></i> Volver al Dashboard</a>
        </div>
    </div>
</div>
<!--
    Modal Bootstrap para mostrar la tabla de usuarios
    Se carga dinámicamente vía AJAX al hacer click en 'Ver Panel de Usuarios'
-->
<div class="modal fade" id="usuariosModal" tabindex="-1" aria-labelledby="usuariosModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg">
    <div class="modal-content">
      <div class="modal-header bg-primary text-white">
        <h5 class="modal-title" id="usuariosModalLabel"><i class="bi bi-people-fill me-2"></i>Usuarios registrados</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Cerrar"></button>
      </div>
      <div class="modal-body p-0">
        <div id="usuariosModalBody" style="max-height:400px;overflow:auto">
          <!-- Tabla dinámica aquí -->
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cerrar</button>
      </div>
    </div>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
// =============================
// Script para cargar usuarios vía AJAX y mostrar en el modal
// =============================
document.getElementById('verUsuariosBtn').addEventListener('click', function(e) {
    e.preventDefault();
    const modalBody = document.getElementById('usuariosModalBody');
    // Muestra spinner de carga
    modalBody.innerHTML = '<div class="text-center my-4"><div class="spinner-border text-primary" role="status"></div><div>Cargando usuarios...</div></div>';
    const usuariosModal = new bootstrap.Modal(document.getElementById('usuariosModal'));
    usuariosModal.show();
    // Solicita los usuarios al backend
    fetch('php/listar_usuarios.php')
      .then(r=>r.json())
      .then(data=>{
        if(data.success) {
            // Renderiza la tabla de usuarios
            let html = `<div class='table-responsive'><table class='table table-sm table-hover align-middle mb-0'><thead class='table-light'><tr><th>Usuario</th><th>Horas</th><th>Rol</th></tr></thead><tbody>`;
            data.usuarios.forEach(u=>{
                html += `<tr><td><i class='bi bi-person-circle text-primary'></i> ${u.usuario}</td><td>${u.horas_disponibles}</td><td>${u.es_admin==1?'<span class=\'badge bg-success\'>Admin</span>':'Usuario'}</td></tr>`;
            });
            html += '</tbody></table></div>';
            modalBody.innerHTML = html;
        } else {
            modalBody.innerHTML = `<div class='alert alert-danger mb-0'>${data.error||'Error al cargar usuarios.'}</div>`;
        }
      })
      .catch(()=>{
        modalBody.innerHTML = `<div class='alert alert-danger mb-0'>Error de red al cargar usuarios.</div>`;
      });
});
</script>
</body>
</html>
