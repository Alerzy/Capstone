<!DOCTYPE html>
<html lang="es">
<head>
<style>
#btnNotificaciones i.bi-bell-fill {
  color: #222;
  transition: color 0.2s;
}
#btnNotificaciones:hover i.bi-bell-fill {
  color: #43cea2;
}
.btn-modern {
  border-radius: 1.5em;
  box-shadow: 0 2px 12px rgba(67,206,162,0.10);
  padding: 0.5em 1.4em;
  font-weight: 600;
  font-size: 1.07em;
  border: none;
  outline: none;
  position: relative;
  overflow: hidden;
  transition: background 0.18s, color 0.18s, box-shadow 0.18s, transform 0.12s;
}
.btn-modern:active {
  transform: scale(0.97);
}
.btn-modern:focus {
  outline: 2px solid #43cea2;
}
.btn-info-custom {
  background: linear-gradient(90deg,#43cea2 0%,#21cbf3 100%);
  color: #fff;
}
.btn-info-custom:hover {
  background: linear-gradient(90deg,#21cbf3 0%,#43cea2 100%);
  color: #fff;
  box-shadow: 0 4px 18px rgba(67,206,162,0.18);
}
.btn-danger-custom {
  background: linear-gradient(90deg,#ff5858 0%,#f09819 100%);
  color: #fff;
}
.btn-danger-custom:hover {
  background: linear-gradient(90deg,#f09819 0%,#ff5858 100%);
  color: #fff;
  box-shadow: 0 4px 18px rgba(255,88,88,0.16);
}
/* Ripple effect */
.btn-modern::after {
  content: '';
  position: absolute;
  border-radius: 50%;
  opacity: 0;
  pointer-events: none;
  transform: scale(1);
  background: rgba(255,255,255,0.32);
  transition: opacity 0.45s, transform 0.45s;
}
.btn-modern:active::after {
  opacity: 1;
  transform: scale(2.5);
  transition: 0s;
}
</style>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Banco de Tiempo - Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>
    <link rel="stylesheet" href="css/dashboard.css" />
</head>
<body style="background: linear-gradient(to right, #c1dff0, #e8f4fa);">

<!-- Contenedor principal del dashboard -->
<div class="container mt-5">
    <?php
// =========================================
// Panel principal del usuario (dashboard)
// Muestra intercambios, chat, notificaciones y acciones principales
// =========================================

session_start();
?>

<?php
include_once 'php/db_config.php';
$usuario = $_SESSION['usuario'];
$resSaldo = $conn->query("SELECT horas_disponibles FROM usuarios WHERE usuario='$usuario'");
$horas = 0;
if ($row = $resSaldo->fetch_assoc()) $horas = $row['horas_disponibles'];
$conn->close();
?>
    <!-- Saludo de bienvenida -->
    <h1 class="text-center mb-2 animate__animated animate__fadeInDown">
  🎊 Te damos la bienvenida, <span style="color:#21cbf3;"><?php echo htmlspecialchars($_SESSION['usuario']); ?></span>! 🎊
</h1>
<p class="text-center fw-semibold fs-5" style="color:#2196f3;">
  ¡Gracias por ser parte de nuestra comunidad Banco de Tiempo!
</p>
<p class="text-center mb-4"><span class="badge bg-success fs-5">Saldo: <?php echo $horas; ?> horas</span></p>
<p class="text-center fs-5 mb-5" style="color:#555;">
    Nos alegra tenerte de vuelta en tu Banco de Tiempo. Explora, comparte y conecta.
</p>

        <!-- Botón Cerrar Sesión arriba a la derecha -->
        <!-- Contenedor de botones de notificaciones y logout -->
    <div style="position: fixed; top: 20px; right: 30px; z-index: 1100; display: flex; gap: 18px; align-items: center;">
        <!-- Notificaciones -->
        <div class="dropdown" id="notificacionesDropdown" style="position:relative;">
          <button class="btn btn-glass position-relative shadow" id="btnNotificaciones" data-bs-toggle="dropdown" aria-expanded="false" title="Notificaciones" style="backdrop-filter: blur(8px); background:rgba(32,180,180,0.18); border:none;">
            <i class="bi bi-bell-fill fs-4" style="color:#222; transition:color 0.2s;"></i>
            <span class="position-absolute top-0 start-100 translate-middle badge rounded-circle bg-success shadow" id="badgeNotificaciones" style="display:none; min-width:22px; min-height:22px; font-size:1rem; border:2px solid #fff;">0</span>
          </button>
          <ul class="dropdown-menu dropdown-menu-end shadow" style="width:340px; max-height:350px; overflow-y:auto;" id="listaNotificaciones">
            <li class="dropdown-item text-center text-muted">Sin notificaciones</li>
          </ul>
        </div>
        <a href="perfil.php?usuario=<?php echo urlencode($_SESSION['usuario']); ?>" class="btn btn-modern btn-info-custom me-1">Mi Perfil</a>
        <button class="btn btn-modern btn-danger-custom" onclick="window.location.href='php/logout.php'">Cerrar Sesión</button>
    </div>

    <!-- Toast de notificación -->
    <div class="position-fixed bottom-0 end-0 p-3" style="z-index: 2000">
      <div id="toastNotificacion" class="toast align-items-center border-0 shadow-lg" role="alert" aria-live="assertive" aria-atomic="true" style="backdrop-filter: blur(10px); background: rgba(255,255,255,0.82); border-radius: 1.2rem; border: 1.5px solid #e0eafc; color: #185a9d; min-width: 290px;">
        <div class="d-flex">
          <div class="toast-body fw-semibold" id="toastNotificacionMsg">
            <!-- Mensaje -->
          </div>
          <button type="button" class="btn-close me-2 m-auto" data-bs-dismiss="toast" aria-label="Cerrar" style="filter: grayscale(1) brightness(1.6);"></button>
        </div>
      </div>
    </div>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" />
    <script>
    let ultimasNotificaciones = [];
    function cargarNotificaciones(marcarLeidas = false) {
      fetch('php/notificaciones_ajax.php', {
        method: marcarLeidas ? 'POST' : 'GET',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: marcarLeidas ? 'accion=marcar_leidas' : undefined
      })
      .then(r => r.json())
      .then(data => {
        if (!data.notificaciones) return;
        const lista = document.getElementById('listaNotificaciones');
        lista.innerHTML = '';
        let nuevas = 0;
        data.notificaciones.forEach(n => { if (n.leida == 0) nuevas++; });
        document.getElementById('badgeNotificaciones').style.display = nuevas > 0 ? 'inline-block' : 'none';
        document.getElementById('badgeNotificaciones').textContent = nuevas;
        if (data.notificaciones.length === 0) {
          lista.innerHTML = '<li class="dropdown-item text-center text-muted">Sin notificaciones</li>';
        } else {
          data.notificaciones.forEach(n => {
            const li = document.createElement('li');
            li.className = `dropdown-item${n.leida == 0 ? ' fw-bold bg-light' : ''}`;
            li.innerHTML = `<i class="bi bi-dot" style="color:${n.leida == 0 ? '#0d6efd' : '#bbb'}"></i> ${n.mensaje}<br><small class="text-muted">${n.fecha.replace('T',' ').substring(0,16)}</small>`;
            lista.appendChild(li);
          });
        }
        // Toast si hay nuevas no leídas
        if (ultimasNotificaciones.length > 0 && data.notificaciones.length > 0) {
          const nuevasNoLeidas = data.notificaciones.filter(n => n.leida == 0 && !ultimasNotificaciones.some(u => u.id == n.id));
          if (nuevasNoLeidas.length > 0) {
            mostrarToast(nuevasNoLeidas[0].mensaje);
          }
        }
        ultimasNotificaciones = data.notificaciones;
      });
    }
    function mostrarToast(msg) {
      document.getElementById('toastNotificacionMsg').textContent = msg;
      const toast = new bootstrap.Toast(document.getElementById('toastNotificacion'));
      toast.show();
    }
    // Polling cada 10s
    setInterval(() => cargarNotificaciones(), 10000);
    // Al abrir el dropdown, marcar como leídas
    document.addEventListener('DOMContentLoaded', function() {
      cargarNotificaciones();
      document.getElementById('btnNotificaciones').addEventListener('click', function(){
        setTimeout(() => cargarNotificaciones(true), 500);
      });
    });
    // Listener para notificaciones de chat
    document.addEventListener('click', function(e) {
      let chatElem = e.target.closest('.chat-noti');
      if (chatElem) {
        e.preventDefault();
        const intercambioId = chatElem.getAttribute('data-intercambio');
        const receptor = chatElem.getAttribute('data-receptor');
        if (typeof abrirChatModal === 'function') {
          abrirChatModal(intercambioId, receptor);
        } else {
          alert('Función de chat no disponible.');
        }
      }
    });
    </script>

        <!-- Tarjetas de acciones principales -->
    <div class="row g-4 justify-content-center">

        <div class="col-12 col-sm-6 col-md-4 col-lg-3 d-flex justify-content-center">
            <div class="card text-white bg-primary shadow-sm w-100" style="max-width: 270px;" onclick="mostrarFormulario()">
                <div class="card-body text-center">
                    <h4 class="card-title">Ofrecer</h4>
                    <p class="card-text">Publica un servicio que quieras intercambiar.</p>
                </div>
            </div>
        </div>

        <div class="col-12 col-sm-6 col-md-4 col-lg-3 d-flex justify-content-center">
            <div class="card text-white bg-primary shadow-sm w-100" style="max-width: 270px;" onclick="mostrarOfertas()">
                <div class="card-body text-center">
                    <h4 class="card-title">Ver Intercambios</h4>
                    <p class="card-text">Consulta las ofertas disponibles.</p>
                </div>
            </div>
        </div>

        <div class="col-12 col-sm-6 col-md-4 col-lg-3 d-flex justify-content-center">
            <div class="card text-white bg-primary shadow-sm w-100" style="max-width: 270px;" onclick="mostrarHistorial()">
                <div class="card-body text-center">
                    <h4 class="card-title">Ver Historial</h4>
                    <p class="card-text">Revisa tus movimientos.</p>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Formulario oculto -->
<!-- Formulario para ofrecer un nuevo intercambio -->
<div id="formularioIntercambio" class="container mt-4 d-none animate__animated animate__fadeIn">
    <!-- Encabezado animoso con icono y mensaje motivador -->
    <div class="text-center mb-3">
        <span class="badge bg-info fs-5 mb-2" style="background: linear-gradient(90deg,#21cbf3,#2196f3); color: #fff; box-shadow: 0 2px 12px rgba(33,203,243,0.13); letter-spacing: 0.5px;">
            <i class="bi bi-stars"></i> ¡Comparte tu talento y haz comunidad!
        </span>
        <h2 class="mb-1 animate__animated animate__fadeInDown" style="color:#2196f3; font-weight:700; letter-spacing:0.5px;">
            <i class="bi bi-arrow-repeat"></i> Ofrecer un Intercambio
        </h2>
        <p class="fs-6 text-secondary mb-0 animate__animated animate__fadeInUp">Publica tu oferta y ayuda a que la red de favores crezca. ¡Cada hora ofrecida es una oportunidad de conectar!</p>
    </div>
    
    <form action="php/ofrecer_intercambio.php" method="POST" class="border p-4 rounded bg-white shadow-sm" style="border: 2px solid #21cbf3; box-shadow: 0 4px 18px rgba(33,203,243,0.09);">

        <div class="mb-3">
            <label for="servicio" class="form-label"><i class="bi bi-hand-thumbs-up me-1 text-primary"></i> Servicio que ofreces:</label>
            <input type="text" class="form-control" name="servicio" id="servicio" required>
        </div>

        <div class="mb-3">
            <label for="horas_ofrecidas" class="form-label"><i class="bi bi-clock-history me-1 text-primary"></i> Horas que ofreces:</label>
            <input type="number" class="form-control" name="horas_ofrecidas" id="horas_ofrecidas" required>
        </div>

        <div class="mb-3">
            <label for="servicio_cambio" class="form-label"><i class="bi bi-arrow-left-right me-1 text-primary"></i> Servicio que deseas a cambio:</label>
            <input type="text" class="form-control" name="servicio_cambio" id="servicio_cambio" required>
        </div>

        <div class="mb-3">
            <label for="horas_deseadas" class="form-label"><i class="bi bi-hourglass-split me-1 text-primary"></i> Horas que deseas a cambio:</label>
            <input type="number" class="form-control" name="horas_deseadas" id="horas_deseadas" required>
        </div>

        <div class="mb-3">
            <label for="descripcion" class="form-label"><i class="bi bi-chat-dots me-1 text-primary"></i> Descripción de tu oferta:</label>
            <textarea class="form-control" name="descripcion" id="descripcion" rows="3" required></textarea>
        </div>

        <button type="submit" class="w-100 py-3 animate__animated" style="
    background: linear-gradient(90deg,#21cbf3,#2196f3);
    color: #fff;
    font-weight:700;
    font-size:1.35em;
    letter-spacing:0.5px;
    border: none;
    border-radius: 10px;
    box-shadow: 0 4px 18px rgba(33,203,243,0.13);
    transition: background 0.2s, transform 0.2s;
">
    <i class="bi bi-send-plus me-1"></i> ¡Publicar mi Intercambio!
</button>
<p class="text-center mt-3 text-muted" style="font-size:0.97em;">
    <i class="bi bi-lightbulb-fill text-warning"></i> Recuerda: ¡Cuanto más detallada tu oferta, más fácil será conectar con otros!
</p>
    </form>
</div>

<script>
// Obtener el usuario logueado desde PHP para validación en JS
const usuarioLogueado = '<?php echo htmlspecialchars($_SESSION['usuario']); ?>';

function mostrarFormulario() {
    var formulario = document.getElementById("formularioIntercambio");
    var ofertas = document.getElementById("contenedorOfertas");
    var historial = document.getElementById("contenedorHistorial");
    formulario.classList.remove("d-none");
    ofertas.classList.add("d-none");
    if (historial) historial.style.display = 'none';
}
</script>


<!-- Contenedor de ofertas de intercambios disponibles -->
<div id="contenedorOfertas" class="container mt-4 d-none animate__animated animate__fadeIn">
    <h2 class="text-center mb-4">Intercambios Disponibles</h2>
    <div id="ofertasLista" class="row g-3"></div>
</div>

<script>

function mostrarOfertas() {
    var ofertas = document.getElementById("contenedorOfertas");
    var formulario = document.getElementById("formularioIntercambio");
    var historial = document.getElementById("contenedorHistorial");
    ofertas.classList.remove("d-none");
    formulario.classList.add("d-none");
    if (historial) historial.style.display = 'none';

    fetch('php/ver_intercambios_ajax.php')
        .then(response => response.json())
        .then(data => {
            var ofertasLista = document.getElementById("ofertasLista");
            ofertasLista.innerHTML = "";
            data.forEach(oferta => {
                if(oferta.estado === 'aceptado') {
                  return; // omitir de la lista
                }
                var card = document.createElement("div");
                card.className = "col-md-6";
                let estadoHtml = '';
                let botonHtml = '';
                estadoHtml = `<span class="badge bg-warning text-dark">Pendiente</span>`;
                // Evitar que el usuario acepte su propio intercambio
                if (oferta.usuario !== usuarioLogueado) {
                    botonHtml = `<button class=\"btn btn-primary w-100\" onclick=\"aceptarIntercambio(${oferta.id})\">Aceptar Intercambio</button>`;
                } else {
                    botonHtml = '';
                }
                card.innerHTML = `
                    <div class="card shadow-sm border-0 mb-3" style="background-color:#ffffff; border-left:5px solid #0d6efd;">
                        <div class="card-body">
                            <h5 class="card-title text-primary">${oferta.usuario} ofrece: ${oferta.servicio_ofrecido} (${oferta.horas_ofrecidas} hrs)</h5>
                            <p class="card-text text-primary">A cambio de: <strong>${oferta.servicio_deseado}</strong> (${oferta.horas_deseadas} hrs)</p>
                            <p class="card-text text-muted">${oferta.descripcion}</p>
                            <p class="card-text">${estadoHtml}</p>
                            <p class="card-text text-end"><small class="text-muted">Publicado: ${oferta.fecha_creacion}</small></p>
                            ${botonHtml}
                            <div class="d-flex gap-2 mt-2">
                              <a href="/Banco de tiempo/perfil.php?usuario=${encodeURIComponent(oferta.usuario)}" target="_blank" class="btn btn-outline-info btn-sm" title="Ver Perfil">
                                <i class="bi bi-person-circle"></i> Ver Perfil
                              </a>
                            </div>
                        </div>
                    </div>
                `;
                ofertasLista.appendChild(card);
            });
        })
        .catch(error => console.error('Error al cargar intercambios:', error));
}

// Nueva función para aceptar intercambio
function aceptarIntercambio(id) {
    if (confirm('¿Estás seguro de aceptar este intercambio?')) {
        window.location.href = `php/aceptar_intercambio.php?id=${id}`;
    }
}

</script>

<!-- Historial de Intercambios -->
<div class="container mt-4 animate__animated animate__fadeIn" id="contenedorHistorial" style="display:none;">
    <h2 class="text-center mb-4">Mi Historial de Intercambios</h2>
    <ul class="nav nav-tabs mb-3" id="historialTabs">
        <li class="nav-item">
            <button class="nav-link active" onclick="cargarHistorial('publicados', this)">Mis Publicaciones</button>
        </li>
        <li class="nav-item">
            <button class="nav-link" onclick="cargarHistorial('aceptados', this)">Aceptados por mí</button>
        </li>
        <li class="nav-item">
            <button class="nav-link" onclick="cargarHistorial('me_aceptaron', this)">Me aceptaron</button>
        </li>
    </ul>
    <div id="historialLista" class="row g-3"></div>
</div>



<script>
function mostrarHistorial() {
    var historial = document.getElementById("contenedorHistorial");
    var formulario = document.getElementById("formularioIntercambio");
    var ofertas = document.getElementById("contenedorOfertas");
    historial.style.display = '';
    formulario.classList.add("d-none");
    ofertas.classList.add("d-none");
    cargarHistorial('publicados', document.querySelector('#historialTabs .nav-link.active'));
}

function cargarHistorial(tipo, btn) {
    // Cambia pestaña activa
    document.querySelectorAll('#historialTabs .nav-link').forEach(el => el.classList.remove('active'));
    if (btn) btn.classList.add('active');
    fetch('php/historial_intercambios_ajax.php?tipo=' + tipo)
        .then(response => response.json())
        .then(data => {
            var historialLista = document.getElementById("historialLista");
            historialLista.innerHTML = "";
            if (data.length === 0) {
                historialLista.innerHTML = '<div class="col-12"><div class="alert alert-info">No hay resultados para mostrar.</div></div>';
                return;
            }
            data.forEach(oferta => {
                var card = document.createElement("div");
                card.className = "col-md-6";
                // Estado y lógica de confirmación
                let estadoHtml = '';
                let confirmarBtn = '';
                if (oferta.estado === 'finalizado') {
                  estadoHtml = `<span class='badge bg-success'>Finalizado</span>`;
                } else if (oferta.estado === 'aceptado') {
                  // Lógica de confirmaciones
                  let yoOfertante = oferta.usuario === usuarioLogueado;
                  let yoAceptante = oferta.aceptado_por === usuarioLogueado;
                  let confirmadoPorMi = (yoOfertante && oferta.confirmado_por_ofertante == 1) || (yoAceptante && oferta.confirmado_por_aceptante == 1);
                  let confirmadoPorOtro = (yoOfertante && oferta.confirmado_por_aceptante == 1) || (yoAceptante && oferta.confirmado_por_ofertante == 1);
                  if (!confirmadoPorMi) {
                    confirmarBtn = `<button class='btn btn-success btn-sm mt-2' onclick='confirmarFinalizacion(${oferta.id})'>Confirmar finalización</button>`;
                  } else if (!confirmadoPorOtro) {
                    estadoHtml = `<span class='badge bg-warning text-dark'>Esperando confirmación del otro usuario</span>`;
                  } else {
                    estadoHtml = `<span class='badge bg-success'>Finalizando...</span>`;
                  }
                  if (!estadoHtml) estadoHtml = `<span class='badge bg-info'>Aceptado${oferta.aceptado_por ? ' por ' + oferta.aceptado_por : ''}</span>`;
                } else {
                  estadoHtml = `<span class='badge bg-warning text-dark'>Pendiente</span>`;
                }
                // Determinar el otro usuario del chat
                let otroUsuario = oferta.usuario === usuarioLogueado ? oferta.aceptado_por : oferta.usuario;
                let chatBtn = '';
                if (oferta.estado === 'aceptado' && otroUsuario && otroUsuario !== usuarioLogueado) {
                    chatBtn = `<button class='btn btn-outline-primary btn-sm mt-2' onclick='abrirChatModal(${oferta.id}, "${otroUsuario}")'>Chat</button>`;
                }
                let valorarBtn = '';
                if (
                  oferta.estado === 'finalizado' &&
                  oferta.usuario !== oferta.aceptado_por && // Solo si hubo dos usuarios
                  (
                    // Mostrar al usuario logueado si aún no valoró
                    (oferta.usuario === usuarioLogueado && !oferta.valoracion_ofertante) ||
                    (oferta.aceptado_por === usuarioLogueado && !oferta.valoracion_aceptante)
                  )
                ) {
                  let evaluado = oferta.usuario === usuarioLogueado ? oferta.aceptado_por : oferta.usuario;
                  valorarBtn = `<button id='btnValorar_${oferta.id}' class='btn btn-outline-success btn-sm mt-2 me-2' onclick='mostrarModalValoracion(${oferta.id}, \"${evaluado}\")'>Valorar</button>`;
                }
                card.innerHTML = `
                    <div class="card shadow-sm border-0 mb-3" style="background-color:#f8f9fa; border-left:5px solid #0d6efd;">
                        <div class="card-body">
                            <h5 class="card-title text-primary">${oferta.usuario} ofrece: ${oferta.servicio_ofrecido} (${oferta.horas_ofrecidas} hrs)</h5>
                            <p class="card-text text-primary">A cambio de: <strong>${oferta.servicio_deseado}</strong> (${oferta.horas_deseadas} hrs)</p>
                            <p class="card-text text-muted">${oferta.descripcion}</p>
                            <p class="card-text">${estadoHtml.replace(/Aceptado por.+/,'')}</p>
                            <p class="card-text text-end"><small class="text-muted">Publicado: ${oferta.fecha_creacion}</small></p>
                            ${chatBtn}
                            ${confirmarBtn}
                            ${valorarBtn}
                            ${(oferta.aceptado_por === usuarioLogueado && oferta.estado === 'aceptado') ? `<button class='btn btn-outline-warning btn-sm mt-2' onclick='cancelarAceptacion(${oferta.id})'>Cancelar aceptación</button>` : ''}
                            ${(oferta.usuario === usuarioLogueado) ? `
  ${(oferta.estado !== 'finalizado') ? `<button class='btn btn-outline-primary btn-sm mt-2 me-2' onclick='abrirEditarModal(${JSON.stringify(oferta)})'>Editar</button>` : ''}
  <button class='btn btn-outline-danger btn-sm mt-2' onclick='eliminarPublicacion(${oferta.id})'>Eliminar</button>
` : ''}
                        </div>
                    </div>
                `;
                historialLista.appendChild(card);
            });
        })
        .catch(error => {
            var historialLista = document.getElementById("historialLista");
            historialLista.innerHTML = '<div class="col-12"><div class="alert alert-danger">Error al cargar historial.</div></div>';
        });
}
</script>

<!-- Modal Chat -->
<div class="modal fade" id="chatModal" tabindex="-1" aria-labelledby="chatModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="chatModalLabel">Chat con <span id="chatCon"></span></h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
      </div>
      <div id="chatInfoIntercambio"></div>
      <div class="modal-body p-0" style="background:#f4f8fb;">
      </div>
      <div class="modal-body p-0" style="background:#f4f8fb;">
        <div id="chatMensajes" style="height:320px; overflow-y:auto; padding:15px;"></div>
      </div>
      <div class="modal-footer">
        <form id="chatForm" class="w-100 d-flex gap-2">
          <input type="hidden" id="chatIntercambioId">
          <input type="hidden" id="chatReceptor">
          <input type="text" class="form-control" id="chatMensaje" placeholder="Escribe tu mensaje..." autocomplete="off" required>
          <button type="submit" class="btn btn-primary">Enviar</button>
        </form>
      </div>
    </div>
  </div>
</div>

<script>
let chatInterval = null;
function abrirChatModal(intercambioId, receptor) {
    document.getElementById('chatIntercambioId').value = intercambioId;
    document.getElementById('chatReceptor').value = receptor;
    document.getElementById('chatCon').textContent = receptor;
    document.getElementById('chatMensaje').value = '';
    // Buscar detalles del intercambio y mostrarlos
    fetch('php/ver_intercambios_ajax.php?id=' + intercambioId)
      .then(r => r.json())
      .then(intercambios => {
        const inter = intercambios && intercambios.length ? intercambios[0] : null;
        let info = '';
        if (inter) {
          info = `<div class='mb-2 p-2 rounded bg-light border text-secondary'>`+
                 `<div><b>Ofrece:</b> ${inter.usuario} - ${inter.servicio_ofrecido} (${inter.horas_ofrecidas} hrs)</div>`+
                 `<div><b>Busca:</b> ${inter.servicio_deseado} (${inter.horas_deseadas} hrs)</div>`+
                 `<div class='small text-muted'>${inter.descripcion || ''}</div>`+
                 `</div>`;
        } else {
          info = `<div class='mb-2 p-2 rounded bg-light border text-secondary'>No se encontró información del intercambio.</div>`;
        }
        document.getElementById('chatInfoIntercambio').innerHTML = info;
      });
    cargarMensajesChat();
    var chatModal = new bootstrap.Modal(document.getElementById('chatModal'));
    chatModal.show();
    if (chatInterval) clearInterval(chatInterval);
    chatInterval = setInterval(cargarMensajesChat, 3000); // auto-refresh cada 3s
    document.getElementById('chatModal').addEventListener('hidden.bs.modal', function () {
        if (chatInterval) clearInterval(chatInterval);
    }, {once:true});
}

function cargarMensajesChat() {
    let intercambioId = document.getElementById('chatIntercambioId').value;
    fetch('php/mensajes_chat.php?intercambio_id='+intercambioId)
        .then(r=>r.json())
        .then(data => {
            let chatMensajes = document.getElementById('chatMensajes');
            chatMensajes.innerHTML = '';
            data.forEach(msg => {
                let align = msg.emisor === usuarioLogueado ? 'end' : 'start';
                let color = msg.emisor === usuarioLogueado ? '#0d6efd' : '#e4e6eb';
                let textColor = msg.emisor === usuarioLogueado ? 'white' : '#222';
                chatMensajes.innerHTML += `<div class='d-flex justify-content-${align} mb-2'><div style='max-width:70%;background:${color};color:${textColor};border-radius:12px;padding:8px 14px;'>${msg.mensaje}<div class='text-end' style='font-size:0.7em;color:#777;'>${msg.emisor === usuarioLogueado ? 'Tú' : msg.emisor} · ${msg.fecha.substring(11,16)}</div></div></div>`;
            });
            chatMensajes.scrollTop = chatMensajes.scrollHeight;
        });
}

document.getElementById('chatForm').onsubmit = function(e) {
    e.preventDefault();
    let intercambioId = document.getElementById('chatIntercambioId').value;
    let receptor = document.getElementById('chatReceptor').value;
    let mensaje = document.getElementById('chatMensaje').value;
    if (!mensaje.trim()) return;
    fetch('php/enviar_mensaje.php', {
        method:'POST',
        headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body:`intercambio_id=${encodeURIComponent(intercambioId)}&receptor=${encodeURIComponent(receptor)}&mensaje=${encodeURIComponent(mensaje)}`
    })
    .then(r=>r.json())
    .then(data => {
        if(data.success){
            document.getElementById('chatMensaje').value = '';
            cargarMensajesChat();
        }
    });
};
</script>

<!-- Modal Edición de Publicación -->
<div class="modal fade" id="editarModal" tabindex="-1" aria-labelledby="editarModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="editarModalLabel">Editar Publicación</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
      </div>
      <div class="modal-body">
        <form id="formEditarPublicacion">
          <input type="hidden" id="editar_id">
          <div class="mb-3">
            <label class="form-label">Servicio ofrecido</label>
            <input type="text" class="form-control" id="editar_servicio_ofrecido" required>
          </div>
          <div class="mb-3">
            <label class="form-label">Horas ofrecidas</label>
            <input type="number" class="form-control" id="editar_horas_ofrecidas" required>
          </div>
          <div class="mb-3">
            <label class="form-label">Servicio deseado</label>
            <input type="text" class="form-control" id="editar_servicio_deseado" required>
          </div>
          <div class="mb-3">
            <label class="form-label">Horas deseadas</label>
            <input type="number" class="form-control" id="editar_horas_deseadas" required>
          </div>
          <div class="mb-3">
            <label class="form-label">Descripción</label>
            <textarea class="form-control" id="editar_descripcion" rows="3" required></textarea>
          </div>
          <button type="submit" class="btn btn-primary">Guardar Cambios</button>
        </form>
      </div>
    </div>
  </div>
</div>

<script>
function abrirEditarModal(oferta) {
  // Rellenar campos del modal con los datos de la oferta
  document.getElementById('editar_id').value = oferta.id;
  document.getElementById('editar_servicio_ofrecido').value = oferta.servicio_ofrecido;
  document.getElementById('editar_horas_ofrecidas').value = oferta.horas_ofrecidas;
  document.getElementById('editar_servicio_deseado').value = oferta.servicio_deseado;
  document.getElementById('editar_horas_deseadas').value = oferta.horas_deseadas;
  document.getElementById('editar_descripcion').value = oferta.descripcion;
  var modal = new bootstrap.Modal(document.getElementById('editarModal'));
  modal.show();
}

document.getElementById('formEditarPublicacion').onsubmit = function(e) {
  e.preventDefault();
  const form = e.target;
  const datos = {
    id: document.getElementById('editar_id').value,
    servicio_ofrecido: document.getElementById('editar_servicio_ofrecido').value,
    horas_ofrecidas: document.getElementById('editar_horas_ofrecidas').value,
    servicio_deseado: document.getElementById('editar_servicio_deseado').value,
    horas_deseadas: document.getElementById('editar_horas_deseadas').value,
    descripcion: document.getElementById('editar_descripcion').value
  };
  fetch('php/editar_intercambio.php', {
    method: 'POST',
    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
    body: new URLSearchParams(datos)
  })
  .then(r => r.json())
  .then(resp => {
    if(resp.success){
      var modal = bootstrap.Modal.getInstance(document.getElementById('editarModal'));
      modal.hide();
      // Refrescar la lista de publicaciones
      cargarHistorial('publicados', document.querySelector('#historialTabs .nav-link.active'));
      setTimeout(() => {
        alert('¡Publicación editada exitosamente!');
      }, 200);
    } else {
      alert('Error al editar: ' + (resp.error || 'Intenta de nuevo.'));
    }
  })
  .catch(()=>alert('Error de red al editar.'));
};
function eliminarPublicacion(id) {
  if(confirm('¿Estás seguro de eliminar esta publicación? Esta acción no se puede deshacer.')){
    fetch('php/eliminar_intercambio.php', {
      method: 'POST',
      headers: {'Content-Type': 'application/x-www-form-urlencoded'},
      body: 'id=' + encodeURIComponent(id)
    })
    .then(r=>r.json())
    .then(resp=>{
      if(resp.success){
        cargarHistorial('publicados', document.querySelector('#historialTabs .nav-link.active'));
        setTimeout(()=>{
          alert('¡Publicación eliminada exitosamente!');
        }, 200);
      } else {
        alert('Error al eliminar: ' + (resp.error || 'Intenta de nuevo.'));
      }
    })
    .catch(()=>alert('Error de red al eliminar.'));
  }
}
function confirmarFinalizacion(id) {
  if(confirm('¿Confirmas que el intercambio fue realizado y finalizado?')){
    fetch('php/confirmar_finalizar_intercambio.php', {
      method: 'POST',
      headers: {'Content-Type': 'application/x-www-form-urlencoded'},
      body: 'id=' + encodeURIComponent(id)
    })
    .then(r=>r.json())
    .then(resp=>{
      if(resp.success){
        cargarHistorial('publicados', document.querySelector('#historialTabs .nav-link.active'));
        setTimeout(() => {
          if(resp.finalizado){
            alert('¡Intercambio finalizado y horas transferidas!');
            // Buscar el otro usuario para valorar
            fetch('php/ver_intercambios_ajax.php')
              .then(r=>r.json())
              .then(intercambios=>{
                const inter = intercambios.find(i => i.id == id);
                if(inter){
                  let miUsuario = usuarioLogueado;
                  let evaluado = (inter.usuario === miUsuario) ? inter.aceptado_por : inter.usuario;
                  if(evaluado && evaluado !== miUsuario){
                    mostrarModalValoracion(id, evaluado);
                  }
                }
              });
          }else{
            alert('¡Confirmación registrada! Esperando al otro usuario.');
          }
        }, 200);
      } else {
        alert('Error al confirmar: ' + (resp.error || 'Intenta de nuevo.'));
      }
    })
    .catch(()=>alert('Error de red al confirmar.'));
  }
}
function cancelarAceptacion(id) {
  if(confirm('¿Seguro que deseas cancelar este intercambio? Volverá a estar disponible para otros usuarios.')){
    fetch('php/cancelar_aceptacion.php', {
      method: 'POST',
      headers: {'Content-Type': 'application/x-www-form-urlencoded'},
      body: 'id=' + encodeURIComponent(id)
    })
    .then(r=>r.json())
    .then(resp=>{
      if(resp.success){
        cargarHistorial('publicados', document.querySelector('#historialTabs .nav-link.active'));
        setTimeout(()=>{
          alert('¡Aceptación cancelada! El intercambio vuelve a estar disponible.');
        }, 200);
      } else {
        alert('Error al cancelar: ' + (resp.error || 'Intenta de nuevo.'));
      }
    })
    .catch(()=>alert('Error de red al cancelar.'));
  }
}
</script>

<!-- Modal Valoración -->
<div class="modal fade" id="modalValoracion" tabindex="-1" aria-labelledby="modalValoracionLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <form id="formValoracion">
        <div class="modal-header">
          <h5 class="modal-title" id="modalValoracionLabel">Valora tu intercambio</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
        </div>
        <div class="modal-body">
          <input type="hidden" id="valoracion_intercambio_id" name="intercambio_id">
          <input type="hidden" id="valoracion_evaluado" name="evaluado">
          <div class="mb-3">
            <label class="form-label">Puntuación</label>
            <select class="form-select" id="valoracion_puntuacion" name="puntuacion" required>
              <option value="">Selecciona</option>
              <option value="5">5 - Excelente</option>
              <option value="4">4 - Muy bueno</option>
              <option value="3">3 - Bueno</option>
              <option value="2">2 - Regular</option>
              <option value="1">1 - Malo</option>
            </select>
          </div>
          <div class="mb-3">
            <label class="form-label">Comentario</label>
            <textarea class="form-control" id="valoracion_comentario" name="comentario" maxlength="250" required></textarea>
          </div>
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-success">Enviar valoración</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
// Mostrar modal de valoración tras finalizar intercambio
function mostrarModalValoracion(intercambioId, evaluado) {
  document.getElementById('valoracion_intercambio_id').value = intercambioId;
  document.getElementById('valoracion_evaluado').value = evaluado;
  document.getElementById('valoracion_puntuacion').value = '';
  document.getElementById('valoracion_comentario').value = '';
  var modalEl = document.getElementById('modalValoracion');
  var modal = new bootstrap.Modal(modalEl, {backdrop: 'static', keyboard: false});
  // Oculta el botón de cerrar (X)
  modalEl.querySelector('.btn-close').style.display = 'none';
  modal.show();
}
// Envío AJAX de valoración
const formValoracion = document.getElementById('formValoracion');
if(formValoracion){
  formValoracion.onsubmit = function(e){
    e.preventDefault();
    const datos = new FormData(formValoracion);
    fetch('php/enviar_valoracion.php', {
      method: 'POST',
      body: datos
    })
    .then(r=>r.json())
    .then(resp=>{
      if(resp.success){
        bootstrap.Modal.getInstance(document.getElementById('modalValoracion')).hide();
        alert('¡Gracias por valorar!');
        // Oculta solo el botón de este intercambio
        const btnId = 'btnValorar_' + datos.get('intercambio_id');
        const btn = document.getElementById(btnId);
        if(btn) btn.style.display = 'none';

      }else{
        alert('Error al enviar valoración: ' + (resp.error||''));
      }
    }).catch(()=>alert('Error de red al valorar.'));
  };
}
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
